// Problem: Employee Rating
// Assignment: 2
// Question: 1
// Domain: 03_Arrays_Matrices

/* Problem Statement:
Find the maximum number of consecutive working days on which the employee worked more than 6 hours.

Approach:
Keep two counters: current (streak ending at present day) and best (longest streak so far). Reset current if workload <= 6.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector<int> workload(n);
    for (int i = 0; i < n; i++) cin >> workload[i];
    int best = 0;
    int current = 0;
    for (int i = 0; i < n; i++) {
        if (workload[i] > 6) {
            current++;
            best = max(best, current);
        } else {
            current = 0;
        }
    }
    cout << "Employee Rating = " << best << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 7
8 9 4 7 10 12 3
Output: Employee Rating = 3
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q01_Employee_Rating.cpp -o A02_Q01_Employee_Rating.exe && .\A02_Q01_Employee_Rating.exe
