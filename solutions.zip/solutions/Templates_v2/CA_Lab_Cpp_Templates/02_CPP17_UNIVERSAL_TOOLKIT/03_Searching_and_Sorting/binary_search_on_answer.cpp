/* CORE-DSA | CP-ESSENTIAL
Generic first-true binary search on an integer domain [lo,hi]. Predicate must be monotonic.
*/
#include <bits/stdc++.h>
using namespace std;
template<class Predicate> long long firstTrue(long long lo,long long hi,Predicate ok){while(lo<hi){long long mid=lo+(hi-lo)/2;if(ok(mid))hi=mid;else lo=mid+1;}return lo;}
int main(){vector<int>a={7,2,5,10,8};int k=2;auto feasible=[&](long long cap){int groups=1,sum=0;for(int x:a){if(x>cap)return false;if(sum+x>cap)++groups,sum=x;else sum+=x;}return groups<=k;};cout<<firstTrue(10,32,feasible)<<'\n';}
