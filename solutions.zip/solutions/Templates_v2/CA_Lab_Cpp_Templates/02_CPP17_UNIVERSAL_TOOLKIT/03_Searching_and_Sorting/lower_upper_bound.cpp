/* CORE-DSA | CP-ESSENTIAL | Demonstrates STL lower_bound and upper_bound on sorted data. */
#include <bits/stdc++.h>
using namespace std;
int main(){vector<int>a={1,2,2,2,4,7};int x=2;cout<<"first >= x index: "<<(lower_bound(a.begin(),a.end(),x)-a.begin())<<'\n';cout<<"first > x index: "<<(upper_bound(a.begin(),a.end(),x)-a.begin())<<'\n';}
