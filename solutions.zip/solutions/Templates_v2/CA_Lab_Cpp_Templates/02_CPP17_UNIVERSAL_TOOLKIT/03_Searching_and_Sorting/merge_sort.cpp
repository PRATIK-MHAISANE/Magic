/* CORE-DSA | CP-ESSENTIAL | Stable merge sort. Time O(n log n), extra space O(n). */
#include <bits/stdc++.h>
using namespace std;
void mergeSort(vector<int>&a,int l,int r){if(r-l<=1)return;int m=l+(r-l)/2;mergeSort(a,l,m);mergeSort(a,m,r);vector<int>t;int i=l,j=m;while(i<m&&j<r)t.push_back(a[i]<=a[j]?a[i++]:a[j++]);while(i<m)t.push_back(a[i++]);while(j<r)t.push_back(a[j++]);copy(t.begin(),t.end(),a.begin()+l);}
int main(){vector<int>a={5,1,4,2,8,2};mergeSort(a,0,a.size());for(int x:a)cout<<x<<' ';cout<<'\n';}
