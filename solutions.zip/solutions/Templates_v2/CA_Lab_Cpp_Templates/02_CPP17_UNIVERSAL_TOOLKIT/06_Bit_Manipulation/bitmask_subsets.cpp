/* CORE-DSA | CP-ESSENTIAL | Enumerate all subsets of n indexed elements. O(n*2^n) to print. */
#include <bits/stdc++.h>
using namespace std;
int main(){vector<int>a={10,20,30};int n=a.size();for(int mask=0;mask<(1<<n);++mask){cout<<"{";bool first=true;for(int i=0;i<n;++i)if(mask>>i&1){if(!first)cout<<',';cout<<a[i];first=false;}cout<<"}\n";}}
