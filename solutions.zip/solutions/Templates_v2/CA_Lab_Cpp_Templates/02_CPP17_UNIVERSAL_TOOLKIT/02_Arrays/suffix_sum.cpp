/* CORE-DSA | CP-ESSENTIAL | suffix[i] = sum of a[i..n-1]. */
#include <bits/stdc++.h>
using namespace std;
vector<long long> buildSuffix(const vector<int>& a){vector<long long>s(a.size()+1);for(int i=(int)a.size()-1;i>=0;--i)s[i]=s[i+1]+a[i];return s;}
int main(){vector<int>a={2,4,1,7,3};auto s=buildSuffix(a);for(size_t i=0;i<a.size();++i)cout<<s[i]<<' ';cout<<'\n';}
