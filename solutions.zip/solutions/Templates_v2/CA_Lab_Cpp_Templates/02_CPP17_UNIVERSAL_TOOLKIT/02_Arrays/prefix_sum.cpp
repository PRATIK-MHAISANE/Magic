/* CORE-DSA | CP-ESSENTIAL
Prefix sums answer static range-sum queries in O(1) after O(n) preprocessing.
0-based inclusive query [l,r]: pref[r+1]-pref[l].
*/
#include <bits/stdc++.h>
using namespace std;
vector<long long> buildPrefix(const vector<int>& a){ vector<long long> p(a.size()+1); for(size_t i=0;i<a.size();++i)p[i+1]=p[i]+a[i]; return p; }
long long rangeSum(const vector<long long>& p,int l,int r){ if(l<0||r+1>=(int)p.size()||l>r) throw out_of_range("invalid range"); return p[r+1]-p[l]; }
int main(){vector<int>a={2,4,1,7,3};auto p=buildPrefix(a);cout<<rangeSum(p,1,3)<<'\n';}
