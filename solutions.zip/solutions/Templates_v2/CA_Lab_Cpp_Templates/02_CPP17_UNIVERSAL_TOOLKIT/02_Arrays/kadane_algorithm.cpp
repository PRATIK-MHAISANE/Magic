/* CORE-DSA | CP-ESSENTIAL
Maximum subarray sum, including all-negative arrays. Time O(n), space O(1).
*/
#include <bits/stdc++.h>
using namespace std;
long long maxSubarraySum(const vector<int>& a){if(a.empty())throw invalid_argument("empty array");long long cur=a[0],best=a[0];for(size_t i=1;i<a.size();++i){cur=max<long long>(a[i],cur+a[i]);best=max(best,cur);}return best;}
int main(){cout<<maxSubarraySum({-2,1,-3,4,-1,2,1,-5,4})<<'\n';}
