/* CORE-DSA | CP-ESSENTIAL | Frequency counting for arbitrary integer keys. O(n) expected. */
#include <bits/stdc++.h>
using namespace std;
int main(){vector<int>a={3,1,3,2,1,3};unordered_map<int,int>freq;for(int x:a)++freq[x];for(auto [x,c]:freq)cout<<x<<": "<<c<<'\n';}
