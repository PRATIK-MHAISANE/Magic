/* CORE-DSA | CP-ESSENTIAL | Next greater element to the right. O(n). */
#include <bits/stdc++.h>
using namespace std;
vector<int> nextGreaterRight(const vector<int>&a){vector<int>ans(a.size(),-1),st;for(int i=(int)a.size()-1;i>=0;--i){while(!st.empty()&&st.back()<=a[i])st.pop_back();if(!st.empty())ans[i]=st.back();st.push_back(a[i]);}return ans;}
int main(){for(int x:nextGreaterRight({4,5,2,10,8}))cout<<x<<' ';cout<<'\n';}
