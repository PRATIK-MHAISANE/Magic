/* CORE-DSA | CP-ESSENTIAL | DSU with path compression and union by size. Amortized near O(1). */
#include <bits/stdc++.h>
using namespace std;
struct DSU{vector<int>p,sz;DSU(int n):p(n),sz(n,1){iota(p.begin(),p.end(),0);}int find(int x){return p[x]==x?x:p[x]=find(p[x]);}bool unite(int a,int b){a=find(a);b=find(b);if(a==b)return false;if(sz[a]<sz[b])swap(a,b);p[b]=a;sz[a]+=sz[b];return true;}};
int main(){DSU d(5);d.unite(0,1);d.unite(1,2);cout<<(d.find(0)==d.find(2))<<'\n';}
