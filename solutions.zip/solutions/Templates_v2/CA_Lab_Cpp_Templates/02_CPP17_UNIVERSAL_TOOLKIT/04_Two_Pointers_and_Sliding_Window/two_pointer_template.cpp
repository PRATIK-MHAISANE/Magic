/* CORE-DSA | CP-ESSENTIAL | Pair sum in sorted array. Time O(n), space O(1). */
#include <bits/stdc++.h>
using namespace std;
pair<int,int> pairSumSorted(const vector<int>&a,int target){int l=0,r=(int)a.size()-1;while(l<r){long long s=(long long)a[l]+a[r];if(s==target)return {l,r};if(s<target)++l;else --r;}return {-1,-1};}
int main(){vector<int>a={1,2,4,6,9};auto [l,r]=pairSumSorted(a,10);cout<<l<<' '<<r<<'\n';}
