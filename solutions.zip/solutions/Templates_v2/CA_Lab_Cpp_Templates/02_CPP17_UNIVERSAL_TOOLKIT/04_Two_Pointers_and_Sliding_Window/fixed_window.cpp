/* CORE-DSA | CP-ESSENTIAL | Maximum sum of any fixed-size window. O(n). */
#include <bits/stdc++.h>
using namespace std;
long long maxWindowSum(const vector<int>&a,int k){if(k<=0||k>(int)a.size())throw invalid_argument("invalid window size");long long s=accumulate(a.begin(),a.begin()+k,0LL),best=s;for(int i=k;i<(int)a.size();++i){s+=a[i]-a[i-k];best=max(best,s);}return best;}
int main(){cout<<maxWindowSum({2,1,5,1,3,2},3)<<'\n';}
