/* CORE-DSA | CP-ESSENTIAL
Longest positive-array subarray with sum <= limit. Sliding-window shrink condition relies on non-negative values.
*/
#include <bits/stdc++.h>
using namespace std;
int longestAtMostSum(const vector<int>&a,long long limit){int l=0,best=0;long long s=0;for(int r=0;r<(int)a.size();++r){s+=a[r];while(l<=r&&s>limit)s-=a[l++];best=max(best,r-l+1);}return best;}
int main(){cout<<longestAtMostSum({1,2,1,0,1,1,0},4)<<'\n';}
