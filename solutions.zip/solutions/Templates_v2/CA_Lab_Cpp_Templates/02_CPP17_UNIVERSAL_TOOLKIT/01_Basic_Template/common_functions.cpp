/* CORE-DSA | CP-ESSENTIAL
Common integer helpers. GCD uses std::gcd; LCM avoids multiplying before division.
Time: gcd O(log(min(a,b))); lcm inherits gcd complexity.
*/
#include <bits/stdc++.h>
using namespace std; using int64 = long long;
int64 safeLcm(int64 a, int64 b) {
    if (a == 0 || b == 0) return 0;
    return (a / std::gcd(a,b)) * b; // Assumes result fits int64.
}
int main(){ cout << "gcd(24, 18) = " << gcd(24LL,18LL) << '\n'; cout << "lcm(12, 18) = " << safeLcm(12,18) << '\n'; }
