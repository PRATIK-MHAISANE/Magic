/* CORE-DSA | CP-ESSENTIAL | Sort records by first ascending, then second descending. */
#include <bits/stdc++.h>
using namespace std;
int main(){ vector<pair<int,int>> a={{2,4},{1,7},{2,9},{1,3}};
    sort(a.begin(),a.end(),[](const auto& x,const auto& y){ return x.first!=y.first ? x.first<y.first : x.second>y.second; });
    for(auto [x,y]:a) cout<<x<<' '<<y<<'\n';
}
