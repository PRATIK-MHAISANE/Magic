/*
ALGORITHM INFO
Name: C++17 Competitive Programming Starter
Domain: Universal Toolkit | Tags: CORE-DSA, CP-ESSENTIAL
DESCRIPTION: Minimal clean starting point for standalone problem solutions.
WHEN TO USE: At the start of a timed coding problem when fast I/O and common aliases help.
APPROACH: Keep the entry point small; place problem logic in solve().
COMPLEXITY: Depends on solve().
*/
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using pii = pair<int,int>;
using vi = vector<int>;

void solve() {
    // Read input and implement the problem here.
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    // cin >> t; // Uncomment for multiple test cases.
    while (t--) solve();
    return 0;
}
