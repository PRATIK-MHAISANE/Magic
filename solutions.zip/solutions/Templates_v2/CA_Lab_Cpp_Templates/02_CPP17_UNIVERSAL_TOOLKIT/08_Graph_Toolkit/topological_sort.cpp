/* CORE-DSA | CP-ESSENTIAL | Kahn's topological sort. Returns empty if a directed cycle exists. O(V+E). */
#include <bits/stdc++.h>
using namespace std;
vector<int>topologicalSort(const vector<vector<int>>&g){int n=g.size();vector<int>indeg(n);for(auto&v:g)for(int x:v)++indeg[x];queue<int>q;for(int i=0;i<n;++i)if(!indeg[i])q.push(i);vector<int>o;while(!q.empty()){int u=q.front();q.pop();o.push_back(u);for(int v:g[u])if(--indeg[v]==0)q.push(v);}if((int)o.size()!=n)return {};return o;}
int main(){vector<vector<int>>g={{1,2},{3},{3},{}};for(int x:topologicalSort(g))cout<<x<<' ';cout<<'\n';}
