/* CORE-DSA | CP-ESSENTIAL | BFS shortest edge-count distances in an unweighted graph. O(V+E). */
#include <bits/stdc++.h>
using namespace std;
vector<int>bfsDistances(const vector<vector<int>>&g,int s){vector<int>d(g.size(),-1);queue<int>q;d[s]=0;q.push(s);while(!q.empty()){int u=q.front();q.pop();for(int v:g[u])if(d[v]==-1)d[v]=d[u]+1,q.push(v);}return d;}
int main(){vector<vector<int>>g={{1,2},{0,3},{0,3},{1,2}};for(int x:bfsDistances(g,0))cout<<x<<' ';cout<<'\n';}
