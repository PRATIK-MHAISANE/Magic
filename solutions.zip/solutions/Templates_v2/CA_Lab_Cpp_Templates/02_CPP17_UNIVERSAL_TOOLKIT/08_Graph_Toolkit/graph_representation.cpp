/* CORE-DSA | CP-ESSENTIAL | Undirected adjacency-list construction. Space O(V+E). */
#include <bits/stdc++.h>
using namespace std;
int main(){int n=4;vector<vector<int>>g(n);vector<pair<int,int>>edges={{0,1},{0,2},{1,3}};for(auto [u,v]:edges){g[u].push_back(v);g[v].push_back(u);}for(int u=0;u<n;++u){cout<<u<<":";for(int v:g[u])cout<<' '<<v;cout<<'\n';}}
