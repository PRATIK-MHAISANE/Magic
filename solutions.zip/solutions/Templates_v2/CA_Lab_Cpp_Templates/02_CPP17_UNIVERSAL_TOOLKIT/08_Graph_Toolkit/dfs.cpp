/* CORE-DSA | CP-ESSENTIAL | Recursive DFS traversal. O(V+E); recursion depth can reach V. */
#include <bits/stdc++.h>
using namespace std;
void dfs(int u,const vector<vector<int>>&g,vector<char>&vis,vector<int>&order){vis[u]=1;order.push_back(u);for(int v:g[u])if(!vis[v])dfs(v,g,vis,order);}
int main(){vector<vector<int>>g={{1,2},{0,3},{0,3},{1,2}};vector<char>vis(4);vector<int>order;dfs(0,g,vis,order);for(int x:order)cout<<x<<' ';cout<<'\n';}
