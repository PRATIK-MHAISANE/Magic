/* CORE-DSA | CP-ESSENTIAL | Sieve O(n log log n); binary modular exponentiation O(log exponent). */
#include <bits/stdc++.h>
using namespace std;
vector<int>primesUpTo(int n){vector<bool>prime(n+1,true);if(n>=0)prime[0]=false;if(n>=1)prime[1]=false;for(int p=2;1LL*p*p<=n;++p)if(prime[p])for(int j=p*p;j<=n;j+=p)prime[j]=false;vector<int>v;for(int i=2;i<=n;++i)if(prime[i])v.push_back(i);return v;}
long long modPow(long long a,long long e,long long mod){long long r=1%mod;a%=mod;while(e){if(e&1)r=r*a%mod;a=a*a%mod;e>>=1;}return r;}
int main(){for(int p:primesUpTo(30))cout<<p<<' ';cout<<"\n2^10 mod 1000000007 = "<<modPow(2,10,1000000007)<<'\n';}
