/*
==================== ALGORITHM INFO ====================
Name        : Minimum Coin Change (Unlimited Coins)
Domain      : Dynamic Programming / Unbounded Knapsack
CA Lab Link : Assignment 6, Q3 Part A
Category    : Assignment-Based
DESCRIPTION
Finds the minimum number of unlimited-supply coins needed to form a target.
WHEN TO USE
For arbitrary positive denominations; unlike greedy change, DP is generally correct.
APPROACH
Build dp[amount] from all smaller states amount-coin; unreachable states stay INF.
COMPLEXITY
Time : O(number_of_coins * target) | Space : O(target)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
int minCoins(const vector<int>&coins,int target){if(target<0)throw invalid_argument("negative target");const int INF=1e9;vector<int>dp(target+1,INF);dp[0]=0;for(int a=1;a<=target;a++)for(int c:coins){if(c<=0)throw invalid_argument("coins must be positive");if(c<=a&&dp[a-c]!=INF)dp[a]=min(dp[a],dp[a-c]+1);}return dp[target]==INF?-1:dp[target];}
int main(){cout<<minCoins({1,3,4},6)<<'\n';}
