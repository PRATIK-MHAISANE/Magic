/*
==================== ALGORITHM INFO ====================
Name        : Traveling Salesperson - Held-Karp Bitmask DP
Domain      : Dynamic Programming / Bitmask DP
CA Lab Link : Assignment 7, Q7 (source document available)
Category    : Assignment-Based
DESCRIPTION
Finds an exact minimum-cost Hamiltonian cycle from a chosen start vertex.
WHEN TO USE
For small complete weighted graphs (typically n up to about 18, memory permitting).
APPROACH
dp[mask][u] is the cheapest path from start visiting mask and ending at u.
Extend to each unvisited vertex, then return to start.
COMPLEXITY
Time : O(n^2 2^n) | Space : O(n 2^n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
pair<long long,vector<int>> heldKarp(const vector<vector<long long>>&d,int start){int n=d.size();if(n==0||n>20||start<0||start>=n)throw invalid_argument("n must be 1..20 and start valid");const long long INF=LLONG_MAX/4;int N=1<<n;vector<vector<long long>>dp(N,vector<long long>(n,INF));vector<vector<int>>par(N,vector<int>(n,-1));dp[1<<start][start]=0;for(int mask=0;mask<N;mask++){if(!(mask>>start&1))continue;for(int u=0;u<n;u++)if(mask>>u&1&&dp[mask][u]<INF)for(int v=0;v<n;v++)if(!(mask>>v&1)){int nm=mask|1<<v;long long nd=dp[mask][u]+d[u][v];if(nd<dp[nm][v])dp[nm][v]=nd,par[nm][v]=u;}}int full=N-1,last=-1;long long best=INF;for(int u=0;u<n;u++)if(u!=start&&dp[full][u]<INF&&d[u][start]<INF&&dp[full][u]+d[u][start]<best)best=dp[full][u]+d[u][start],last=u;if(n==1)return {0,{start,start}};if(last==-1)return {-1,{}};vector<int>route;int mask=full,u=last;while(u!=-1){route.push_back(u);int p=par[mask][u];mask^=1<<u;u=p;}reverse(route.begin(),route.end());route.push_back(start);return {best,route};}
int main(){vector<vector<long long>>d={{0,10,15,20},{10,0,35,25},{15,35,0,30},{20,25,30,0}};auto [cost,path]=heldKarp(d,0);cout<<"Minimum tour cost: "<<cost<<"\nRoute: ";for(int x:path)cout<<x<<' ';cout<<'\n';}
