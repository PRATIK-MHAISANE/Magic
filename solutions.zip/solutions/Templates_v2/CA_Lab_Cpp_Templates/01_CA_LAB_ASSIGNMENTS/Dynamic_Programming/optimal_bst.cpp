/*
==================== ALGORITHM INFO ====================
Name        : Optimal Binary Search Tree (successful searches only)
Domain      : Dynamic Programming / Interval DP
CA Lab Link : Assignment 7, Q4 (source document available)
Category    : Assignment-Based
DESCRIPTION
Chooses a BST structure minimizing weighted search cost for sorted keys with given successful-search frequencies.
WHEN TO USE
When keys are sorted and only successful-search frequencies are supplied.
APPROACH
Try each key as root for every interval; cost is left + right + interval frequency sum.
COMPLEXITY
Time : O(n^3) | Space : O(n^2)
NOTE
This is the successful-frequency-only version. Full OBST also includes unsuccessful-search probabilities.
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
long long optimalBST(const vector<long long>&f){int n=f.size();vector<vector<long long>>dp(n,vector<long long>(n));vector<long long>pref(n+1);for(int i=0;i<n;i++)pref[i+1]=pref[i]+f[i];for(int len=1;len<=n;len++)for(int l=0;l+len<=n;l++){int r=l+len-1;dp[l][r]=LLONG_MAX;long long sum=pref[r+1]-pref[l];for(int root=l;root<=r;root++){long long left=root>l?dp[l][root-1]:0,right=root<r?dp[root+1][r]:0;dp[l][r]=min(dp[l][r],left+right+sum);}}return n?dp[0][n-1]:0;}
int main(){cout<<optimalBST({34,8,50})<<'\n';}
