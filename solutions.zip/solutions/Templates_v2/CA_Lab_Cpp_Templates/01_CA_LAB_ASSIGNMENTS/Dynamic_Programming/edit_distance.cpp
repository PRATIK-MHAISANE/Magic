/*
==================== ALGORITHM INFO ====================
Name        : Levenshtein Edit Distance
Domain      : Dynamic Programming / String DP
CA Lab Link : Assignment 6, Q5
Category    : Assignment-Based
DESCRIPTION
Computes the minimum insertions, deletions, and substitutions to convert one string to another.
WHEN TO USE
For approximate string matching and sequence transformation cost.
APPROACH
For each prefix pair, take the minimum of insert, delete, and replace; equal chars copy diagonal.
COMPLEXITY
Time : O(mn) | Space : O(n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
int editDistance(const string&a,const string&b){int n=b.size();vector<int>dp(n+1);iota(dp.begin(),dp.end(),0);for(int i=1;i<=(int)a.size();i++){int diagonal=dp[0];dp[0]=i;for(int j=1;j<=n;j++){int old=dp[j];if(a[i-1]==b[j-1])dp[j]=diagonal;else dp[j]=1+min({diagonal,dp[j],dp[j-1]});diagonal=old;}}return dp[n];}
int main(){cout<<editDistance("kitten","sitting")<<'\n';}
