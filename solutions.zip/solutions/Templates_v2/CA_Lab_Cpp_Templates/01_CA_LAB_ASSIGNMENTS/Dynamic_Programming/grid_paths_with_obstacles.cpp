/*
==================== ALGORITHM INFO ====================
Name        : Grid Paths with Obstacles
Domain      : Dynamic Programming / Grid DP
CA Lab Link : Assignment 6, Q1
Category    : Assignment-Based
DESCRIPTION
Counts right/down paths from the top-left to bottom-right while avoiding blocked cells.
WHEN TO USE
For monotone grid movement with blocked cells.
APPROACH
ways[i][j] is zero for obstacles; otherwise it is the sum from top and left.
COMPLEXITY
Time : O(mn) | Space : O(mn), reducible to O(n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
long long countPaths(const vector<vector<int>>&g){if(g.empty()||g[0].empty())return 0;int m=g.size(),n=g[0].size();vector<long long>dp(n);for(int i=0;i<m;i++)for(int j=0;j<n;j++){if(g[i][j])dp[j]=0;else if(i==0&&j==0)dp[j]=1;else if(j>0)dp[j]+=dp[j-1];}return dp[n-1];}
int main(){vector<vector<int>>g={{0,0,0},{0,1,0},{0,0,0}};cout<<countPaths(g)<<'\n';}
