/*
==================== ALGORITHM INFO ====================
Name        : 0/1 Knapsack
Domain      : Dynamic Programming / Optimization
CA Lab Link : Assignment 6, Q2
Category    : Assignment-Based
DESCRIPTION
Maximizes total item value without exceeding capacity; each item is used at most once.
WHEN TO USE
When items are indivisible and the capacity is an integer constraint.
APPROACH
For each item/capacity choose between skipping it and taking it once.
COMPLEXITY
Time : O(nW) | Space : O(W) with descending-capacity 1-D DP
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
long long knapsack01(const vector<int>&w,const vector<int>&v,int cap){if(w.size()!=v.size()||cap<0)throw invalid_argument("invalid input");vector<long long>dp(cap+1);for(int i=0;i<(int)w.size();i++){if(w[i]<=0)throw invalid_argument("weights must be positive");for(int c=cap;c>=w[i];c--)dp[c]=max(dp[c],dp[c-w[i]]+v[i]);}return dp[cap];}
int main(){cout<<knapsack01({2,1,3},{12,10,20},5)<<'\n';}
