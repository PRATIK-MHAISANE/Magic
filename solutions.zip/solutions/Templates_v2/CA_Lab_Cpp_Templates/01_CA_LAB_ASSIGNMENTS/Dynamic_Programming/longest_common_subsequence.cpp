/*
==================== ALGORITHM INFO ====================
Name        : Longest Common Subsequence (with reconstruction)
Domain      : Dynamic Programming / String DP
CA Lab Link : Assignment 6, Q4
Category    : Assignment-Based
DESCRIPTION
Finds a longest sequence appearing in both strings in the same relative order.
WHEN TO USE
For sequence similarity where characters need not be contiguous.
APPROACH
Build a prefix DP table, then walk backwards to reconstruct one LCS.
COMPLEXITY
Time : O(mn) | Space : O(mn)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
string lcs(const string&a,const string&b){int m=a.size(),n=b.size();vector<vector<int>>dp(m+1,vector<int>(n+1));for(int i=1;i<=m;i++)for(int j=1;j<=n;j++)dp[i][j]=(a[i-1]==b[j-1]?dp[i-1][j-1]+1:max(dp[i-1][j],dp[i][j-1]));string s;int i=m,j=n;while(i&&j){if(a[i-1]==b[j-1])s+=a[--i],--j;else if(dp[i-1][j]>=dp[i][j-1])--i;else --j;}reverse(s.begin(),s.end());return s;}
int main(){string s=lcs("ABCBDAB","BDCABA");cout<<"LCS: "<<s<<"\nLength: "<<s.size()<<'\n';}
