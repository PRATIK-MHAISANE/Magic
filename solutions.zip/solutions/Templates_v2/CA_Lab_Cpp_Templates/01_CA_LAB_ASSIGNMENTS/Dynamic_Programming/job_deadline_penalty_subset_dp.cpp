/*
==================== ALGORITHM INFO ====================
Name        : Minimum Late-Job Penalty (Subset DP)
Domain      : Dynamic Programming / Bitmask DP / Scheduling
CA Lab Link : Assignment 7, Q2
Category    : Assignment-Based
DESCRIPTION
Minimizes total penalty when every job is processed once on one machine; a job's penalty
is incurred if its completion time exceeds its deadline.
WHEN TO USE
For small n, where O(n*2^n) subset DP is feasible.
APPROACH
Sort by deadline. A subset is feasible as the on-time prefix if jobs in EDD order finish
by their deadlines. Maximize saved penalties, then subtract from total penalty.
COMPLEXITY
Time : O(n*2^n) | Space : O(2^n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
struct Job { int id, processing, deadline; long long penalty; };
struct Result { long long minimumPenalty; vector<int> order; };
Result minimizeLatePenalty(vector<Job> jobs) {
    int n = (int)jobs.size();
    if (n >= 25) throw invalid_argument("subset DP is intended for small n");
    sort(jobs.begin(), jobs.end(), [](const Job& a, const Job& b) {
        return a.deadline < b.deadline;
    });
    int states = 1 << n;
    vector<long long> time(states), saved(states, -1);
    vector<int> parent(states, -1), last(states, -1);
    long long total = 0;
    for (const auto& j : jobs) total += j.penalty;
    saved[0] = 0;
    for (int mask = 0; mask < states; ++mask) {
        if (saved[mask] < 0) continue;
        for (int j = 0; j < n; ++j) if (!(mask & (1 << j))) {
            int next = mask | (1 << j);
            long long finish = time[mask] + jobs[j].processing;
            if (finish <= jobs[j].deadline && saved[mask] + jobs[j].penalty > saved[next]) {
                time[next] = finish;
                saved[next] = saved[mask] + jobs[j].penalty;
                parent[next] = mask;
                last[next] = j;
            }
        }
    }
    int bestMask = 0;
    for (int mask = 0; mask < states; ++mask)
        if (saved[mask] > saved[bestMask]) bestMask = mask;
    vector<int> onTime;
    for (int mask = bestMask; mask; mask = parent[mask]) onTime.push_back(last[mask]);
    reverse(onTime.begin(), onTime.end());
    vector<bool> chosen(n);
    vector<int> order;
    for (int j : onTime) chosen[j] = true, order.push_back(jobs[j].id);
    for (int j = 0; j < n; ++j) if (!chosen[j]) order.push_back(jobs[j].id);
    return {total - saved[bestMask], order};
}
int main() {
    vector<Job> jobs = {{1, 3, 4, 20}, {2, 2, 3, 10}, {3, 1, 2, 15}, {4, 2, 8, 8}};
    auto ans = minimizeLatePenalty(jobs);
    cout << "Minimum total penalty = " << ans.minimumPenalty << "\nOrder: ";
    for (int id : ans.order) cout << 'J' << id << ' ';
    cout << '\n';
}
