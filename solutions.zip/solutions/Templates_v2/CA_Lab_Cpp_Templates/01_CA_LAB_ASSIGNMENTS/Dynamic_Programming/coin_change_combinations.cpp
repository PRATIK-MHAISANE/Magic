/*
==================== ALGORITHM INFO ====================
Name        : Coin Change - Count Combinations
Domain      : Dynamic Programming / Unbounded Knapsack
CA Lab Link : Assignment 6, Q3 Part B
Category    : Assignment-Based
DESCRIPTION
Counts distinct combinations to form a target with unlimited coin supply.
WHEN TO USE
When order does not matter; each multiset of coins is counted once.
APPROACH
Process each denomination outside, then increase amount from coin to target.
This ordering prevents counting different permutations separately.
COMPLEXITY
Time : O(number_of_coins * target) | Space : O(target)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
long long countCombinations(const vector<int>&coins,int target){if(target<0)throw invalid_argument("negative target");vector<long long>ways(target+1);ways[0]=1;for(int c:coins){if(c<=0)throw invalid_argument("coins must be positive");for(int a=c;a<=target;a++)ways[a]+=ways[a-c];}return ways[target];}
int main(){cout<<countCombinations({1,2,5},5)<<'\n';}
