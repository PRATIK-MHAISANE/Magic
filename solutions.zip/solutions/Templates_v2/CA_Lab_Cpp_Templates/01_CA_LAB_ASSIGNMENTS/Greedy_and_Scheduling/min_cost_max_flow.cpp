/*
==================== ALGORITHM INFO ====================
Name        : Min-Cost Max-Flow (SPFA shortest augmenting paths)
Domain      : Graph Algorithms / Network Flow / Scheduling
CA Lab Link : Assignment 7, Q1 (k operating rooms)
Category    : Assignment-Based Supporting Template
DESCRIPTION
Sends up to a requested flow amount while minimizing total edge cost.
WHEN TO USE
For capacity-constrained selection/scheduling reductions such as k-room weighted intervals.
APPROACH
Build residual reverse edges; repeatedly find a cheapest residual source-sink path and augment.
COMPLEXITY
SPFA has O(VE) worst-case per augmentation; total worst-case O(FVE).
========================================================
*/
#include <bits/stdc++.h>
using namespace std;struct MinCostMaxFlow{struct E{int to,rev,cap,cost;};int n;vector<vector<E>>g;MinCostMaxFlow(int n):n(n),g(n){}void addEdge(int u,int v,int cap,int cost){E a{v,(int)g[v].size(),cap,cost},b{u,(int)g[u].size(),0,-cost};g[u].push_back(a);g[v].push_back(b);}pair<int,long long>run(int s,int t,int limit){int flow=0;long long cost=0;const int INF=1e9;while(flow<limit){vector<int>d(n,INF),pv(n,-1),pe(n,-1);vector<bool>in(n);queue<int>q;d[s]=0;q.push(s);in[s]=1;while(!q.empty()){int u=q.front();q.pop();in[u]=0;for(int i=0;i<(int)g[u].size();i++){auto&e=g[u][i];if(e.cap&&d[e.to]>d[u]+e.cost){d[e.to]=d[u]+e.cost;pv[e.to]=u;pe[e.to]=i;if(!in[e.to])q.push(e.to),in[e.to]=1;}}}if(d[t]==INF)break;int add=limit-flow;for(int v=t;v!=s;v=pv[v])add=min(add,g[pv[v]][pe[v]].cap);for(int v=t;v!=s;v=pv[v]){E&e=g[pv[v]][pe[v]];e.cap-=add;g[v][e.rev].cap+=add;}flow+=add;cost+=1LL*add*d[t];}return {flow,cost};}};
int main(){MinCostMaxFlow f(4);f.addEdge(0,1,1,-5);f.addEdge(0,2,1,-3);f.addEdge(1,3,1,0);f.addEdge(2,3,1,0);auto [flow,cost]=f.run(0,3,2);cout<<"Flow = "<<flow<<", minimum cost = "<<cost<<'\n';}
