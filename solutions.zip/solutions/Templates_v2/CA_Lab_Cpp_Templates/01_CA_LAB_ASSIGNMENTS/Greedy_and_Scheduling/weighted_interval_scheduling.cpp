/*
==================== ALGORITHM INFO ====================
Name        : Weighted Interval Scheduling
Domain      : Dynamic Programming / Scheduling Optimization
CA Lab Link : Assignment 7, Q1 (single operating room)
Category    : Assignment-Based
DESCRIPTION
Selects non-overlapping intervals maximizing total priority/weight.
WHEN TO USE
For one resource/room and weighted jobs; ordinary earliest-finish greedy is not sufficient.
APPROACH
Sort by finish time, binary-search the last compatible job, and use dp[i]=max(skip,take).
COMPLEXITY
Time : O(n log n) | Space : O(n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;struct Job{long long start,finish,weight;int id;};
pair<long long,vector<int>>weightedSchedule(vector<Job>a){sort(a.begin(),a.end(),[](auto&x,auto&y){return x.finish<y.finish;});int n=a.size();vector<long long>ends(n);for(int i=0;i<n;i++)ends[i]=a[i].finish;vector<long long>dp(n+1);vector<int>take(n+1);for(int i=1;i<=n;i++){int j=upper_bound(ends.begin(),ends.begin()+i-1,a[i-1].start)-ends.begin();long long use=a[i-1].weight+dp[j],skip=dp[i-1];if(use>skip)dp[i]=use,take[i]=1;else dp[i]=skip;}vector<int>ids;for(int i=n;i>0;){if(take[i]&&a[i-1].weight+dp[(int)(upper_bound(ends.begin(),ends.begin()+i-1,a[i-1].start)-ends.begin())]==dp[i]){ids.push_back(a[i-1].id);i=(int)(upper_bound(ends.begin(),ends.begin()+i-1,a[i-1].start)-ends.begin());}else --i;}reverse(ids.begin(),ids.end());return {dp[n],ids};}
int main(){vector<Job>j={{1,3,5,1},{2,5,6,2},{4,6,5,3},{6,7,4,4},{5,8,11,5},{7,9,2,6}};auto [best,ids]=weightedSchedule(j);cout<<"Maximum priority: "<<best<<"\nSelected IDs: ";for(int x:ids)cout<<x<<' ';cout<<'\n';}
