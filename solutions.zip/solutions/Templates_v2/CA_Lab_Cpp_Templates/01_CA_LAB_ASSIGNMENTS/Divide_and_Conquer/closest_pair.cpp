/*
==================== ALGORITHM INFO ====================
Name        : Closest Pair of Points
Domain      : Divide and Conquer / Computational Geometry
CA Lab Link : Week 4 Assignment, Q4 (source document available)
Category    : Assignment-Based
DESCRIPTION
Finds the minimum Euclidean distance between any two 2-D points.
WHEN TO USE
For closest-pair queries on a static set of planar points.
APPROACH
Sort by x once; recursively solve halves; merge using a y-sorted strip and
check only the bounded number of following strip points.
COMPLEXITY
Time : O(n log n) | Auxiliary space : O(n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
struct Point{double x,y;};
double d2(const Point&a,const Point&b){double x=a.x-b.x,y=a.y-b.y;return x*x+y*y;}
double solve(vector<Point>& px, vector<Point>& py){
 int n=px.size();
 if(n<=3){double best=1e100;for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)best=min(best,d2(px[i],px[j]));sort(py.begin(),py.end(),[](auto&a,auto&b){return a.y<b.y;});return best;}
 int mid=n/2;double midx=px[mid].x;
 vector<Point> lx(px.begin(),px.begin()+mid),rx(px.begin()+mid,px.end());
 vector<Point> ly,ry;ly.reserve(mid);ry.reserve(n-mid);
 // Partition y-sorted points by membership in the left x-half, preserving duplicates.
 multiset<pair<double,double>> leftKeys;for(const auto&pt:lx)leftKeys.insert({pt.x,pt.y});
 for(const auto&pt:py){auto key=make_pair(pt.x,pt.y);auto it=leftKeys.find(key);if(it!=leftKeys.end()){ly.push_back(pt);leftKeys.erase(it);}else ry.push_back(pt);}
 double best=min(solve(lx,ly),solve(rx,ry));
 vector<Point>strip;for(const auto&pt:py)if((pt.x-midx)*(pt.x-midx)<best)strip.push_back(pt);
 for(size_t i=0;i<strip.size();i++)for(size_t j=i+1;j<strip.size()&&(strip[j].y-strip[i].y)*(strip[j].y-strip[i].y)<best;j++)best=min(best,d2(strip[i],strip[j]));
 return best;
}
double closestPair(vector<Point>p){if(p.size()<2)return 0;sort(p.begin(),p.end(),[](auto&a,auto&b){return a.x<b.x||(a.x==b.x&&a.y<b.y);});vector<Point>py=p;sort(py.begin(),py.end(),[](auto&a,auto&b){return a.y<b.y;});return sqrt(solve(p,py));}
int main(){vector<Point>p={{2,3},{12,30},{40,50},{5,1},{12,10},{3,4}};cout<<fixed<<setprecision(6)<<closestPair(p)<<'\n';}
