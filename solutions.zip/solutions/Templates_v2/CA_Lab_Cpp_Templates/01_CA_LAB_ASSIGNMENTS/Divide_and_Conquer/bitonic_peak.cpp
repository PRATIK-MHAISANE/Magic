/*
==================== ALGORITHM INFO ====================
Name        : Maximum Element in a Bitonic Array
Domain      : Divide and Conquer / Binary Search
CA Lab Link : Week 4 Assignment, Q1 (source document available)
Category    : Assignment-Based
DESCRIPTION
Finds the peak (maximum) in an array that strictly increases and then
strictly decreases.
WHEN TO USE
Use when the input is guaranteed to be bitonic (strict form).
APPROACH
Compare mid with mid+1. If it rises, the peak is to the right;
otherwise the peak is at mid or to the left.
COMPLEXITY
Time : O(log n) | Auxiliary space : O(1)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
int bitonicPeakIndex(const vector<int>& a) {
    if (a.empty()) throw invalid_argument("array must not be empty");
    int lo=0, hi=(int)a.size()-1;
    while(lo<hi){ int mid=lo+(hi-lo)/2; if(a[mid]<a[mid+1]) lo=mid+1; else hi=mid; }
    return lo;
}
int main(){ vector<int>a={1,3,8,12,9,5,2}; int p=bitonicPeakIndex(a); cout<<"Peak = "<<a[p]<<", index = "<<p<<'\n'; }
