/*
==================== ALGORITHM INFO ====================
Name        : Skyline Problem (Divide and Conquer)
Domain      : Divide and Conquer / Computational Geometry
CA Lab Link : Week 4 Assignment, Q3 (source document available)
Category    : Assignment-Based
DESCRIPTION
Returns the visible outer contour of buildings as (x,height) key points.
WHEN TO USE
For combining rectangular building silhouettes efficiently.
APPROACH
Recursively solve each half, then merge two sorted skyline sequences while
tracking the current height contributed by each side.
COMPLEXITY
Time : O(n log n) | Auxiliary space : O(n)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
struct Building{int left,height,right;}; using Point=pair<int,int>;
vector<Point> mergeSky(const vector<Point>&a,const vector<Point>&b){
 vector<Point> out; size_t i=0,j=0; int h1=0,h2=0,prev=-1;
 auto emit=[&](int x){int h=max(h1,h2);if(out.empty()||out.back().second!=h)out.push_back({x,h});};
 while(i<a.size()||j<b.size()){
  int x;
  if(j==b.size()||(i<a.size()&&a[i].first<b[j].first)){x=a[i].first;h1=a[i++].second;}
  else if(i==a.size()||b[j].first<a[i].first){x=b[j].first;h2=b[j++].second;}
  else{x=a[i].first;h1=a[i++].second;h2=b[j++].second;}
  emit(x);
 }
 return out;
}
vector<Point> skylineRec(const vector<Building>&v,int l,int r){if(l==r)return {{v[l].left,v[l].height},{v[l].right,0}};int m=(l+r)/2;return mergeSky(skylineRec(v,l,m),skylineRec(v,m+1,r));}
vector<Point> getSkyline(vector<Building> v){if(v.empty())return {};sort(v.begin(),v.end(),[](auto&a,auto&b){return a.left<b.left;});return skylineRec(v,0,(int)v.size()-1);}
int main(){vector<Building>b={{2,10,9},{3,15,7},{5,12,12},{15,10,20},{19,8,24}};for(auto [x,h]:getSkyline(b))cout<<'('<<x<<','<<h<<") ";cout<<'\n';}
