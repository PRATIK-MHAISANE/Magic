/*
==================== ALGORITHM INFO ====================
Name        : L-shaped Tromino Tiling
Domain      : Divide and Conquer / Recursive Tiling
CA Lab Link : Week 4 Assignment, Q2 (source document available)
Category    : Assignment-Based
DESCRIPTION
Tiles a 2^k by 2^k board with one initially missing cell using L trominoes.
WHEN TO USE
For a power-of-two square board with exactly one missing cell.
APPROACH
Place one central tromino to create one missing cell in each other quadrant,
then recursively tile all four quadrants.
COMPLEXITY
Time : O(n^2) | Auxiliary space : O(n^2) board plus O(log n) recursion
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
void tile(vector<vector<int>>& b,int top,int left,int size,int missingR,int missingC,int& id){
 if(size==1) return; int half=size/2, current=id++;
 int r=top+half-1,c=left+half-1;
 // Quadrant order: top-left, top-right, bottom-left, bottom-right.
 pair<int,int> center[4]={{r,c},{r,c+1},{r+1,c},{r+1,c+1}};
 int missingQ=(missingR>=top+half?2:0)+(missingC>=left+half?1:0);
 for(int q=0;q<4;q++) if(q!=missingQ) b[center[q].first][center[q].second]=current;
 for(int q=0;q<4;q++){
  int nr,nc,nt=top+(q/2)*half,nl=left+(q%2)*half;
  if(q==missingQ){nr=missingR;nc=missingC;} else {nr=center[q].first;nc=center[q].second;}
  tile(b,nt,nl,half,nr,nc,id);
 }
}
int main(){int k=2,n=1<<k; vector<vector<int>> b(n,vector<int>(n,0)); int mr=1,mc=2;b[mr][mc]=-1;int id=1;tile(b,0,0,n,mr,mc,id);for(auto&r:b){for(int x:r)cout<<setw(3)<<x;cout<<'\n';} }
