/*
==================== ALGORITHM INFO ====================
Name        : Minimum Weight Cycle by Edge Removal + Dijkstra
Domain      : Graph Algorithms / Shortest Paths / Cycle Detection
CA Lab Link : Assignment 8, Q1
Category    : Assignment-Based
DESCRIPTION
For an undirected positive-weight graph, finds the minimum cycle by removing each edge in turn,
computing the shortest alternate path between its endpoints, then adding the removed edge weight.
WHEN TO USE
For small/moderate sparse undirected graphs with non-negative weights when this O(E) Dijkstra
approach is acceptable. Parallel edges are supported by edge IDs.
APPROACH
Run Dijkstra while skipping one specific edge ID; minimize path distance plus that edge's weight.
COMPLEXITY
Time : O(E (V+E) log V) | Space : O(V+E)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;using ll=long long;const ll INF=LLONG_MAX/4;
struct Edge{int u,v;ll w;};
ll shortestPathSkipping(const vector<vector<pair<int,int>>>&g,const vector<Edge>&e,int s,int t,int skip){vector<ll>d(g.size(),INF);priority_queue<pair<ll,int>,vector<pair<ll,int>>,greater<pair<ll,int>>>pq;d[s]=0;pq.push({0,s});while(!pq.empty()){auto [du,u]=pq.top();pq.pop();if(du!=d[u])continue;if(u==t)return du;for(auto [v,id]:g[u])if(id!=skip&&du+e[id].w<d[v])d[v]=du+e[id].w,pq.push({d[v],v});}return INF;}
ll minimumCycle(int n,const vector<Edge>&e){vector<vector<pair<int,int>>>g(n);for(int i=0;i<(int)e.size();i++){if(e[i].w<0)throw invalid_argument("weights must be non-negative");g[e[i].u].push_back({e[i].v,i});g[e[i].v].push_back({e[i].u,i});}ll ans=INF;for(int i=0;i<(int)e.size();i++){ll p=shortestPathSkipping(g,e,e[i].u,e[i].v,i);if(p<INF-e[i].w)ans=min(ans,p+e[i].w);}return ans;}
int main(){vector<Edge>e={{0,1,1},{1,2,2},{2,0,3},{2,3,4}};ll x=minimumCycle(4,e);if(x==INF)cout<<"No cycle\n";else cout<<x<<'\n';}
