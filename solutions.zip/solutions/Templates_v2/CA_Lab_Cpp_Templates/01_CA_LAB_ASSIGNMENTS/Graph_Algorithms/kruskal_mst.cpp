/*
==================== ALGORITHM INFO ====================
Name        : Kruskal's Minimum Spanning Tree (DSU)
Domain      : Graph Algorithms / MST / Disjoint Set Union
CA Lab Link : Assignment 7, Q6 (source document available)
Category    : Assignment-Based
DESCRIPTION
Sorts edges by weight and adds an edge when it joins two different components.
WHEN TO USE
For undirected weighted graphs; detects disconnected graphs (no spanning tree).
APPROACH
Sort edges, use DSU with path compression and union by size to avoid cycles.
COMPLEXITY
Time : O(E log E) | Space : O(V)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;struct DSU{vector<int>p,sz;DSU(int n):p(n),sz(n,1){iota(p.begin(),p.end(),0);}int find(int x){return p[x]==x?x:p[x]=find(p[x]);}bool unite(int a,int b){a=find(a);b=find(b);if(a==b)return false;if(sz[a]<sz[b])swap(a,b);p[b]=a;sz[a]+=sz[b];return true;}};
struct Edge{int u,v;long long w;};
pair<long long,vector<Edge>>kruskal(int n,vector<Edge>e){sort(e.begin(),e.end(),[](auto&a,auto&b){return a.w<b.w;});DSU d(n);long long total=0;vector<Edge>chosen;for(auto x:e)if(d.unite(x.u,x.v)){total+=x.w;chosen.push_back(x);if((int)chosen.size()==n-1)break;}if(n>0&&(int)chosen.size()!=n-1)throw runtime_error("graph is disconnected");return {total,chosen};}
int main(){vector<Edge>e={{0,1,10},{0,2,6},{0,3,5},{1,3,15},{2,3,4}};auto [w,t]=kruskal(4,e);cout<<"MST weight: "<<w<<'\n';for(auto x:t)cout<<x.u<<" - "<<x.v<<" : "<<x.w<<'\n';}
