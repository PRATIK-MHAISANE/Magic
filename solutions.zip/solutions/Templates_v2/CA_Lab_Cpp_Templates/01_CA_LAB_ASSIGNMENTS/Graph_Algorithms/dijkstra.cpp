/*
==================== ALGORITHM INFO ====================
Name        : Dijkstra's Shortest Path (priority queue)
Domain      : Graph Algorithms / Shortest Paths
CA Lab Link : Assignment 8, Q1 uses Dijkstra as a subroutine
Category    : Assignment-Based Foundation
DESCRIPTION
Finds single-source shortest distances in a graph with non-negative edge weights.
WHEN TO USE
Use for non-negative weights; use Bellman-Ford when negative edges are allowed.
APPROACH
Maintain tentative distances in a min-heap and relax outgoing edges.
COMPLEXITY
Time : O((V+E) log V) | Space : O(V+E)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;using Edge=pair<int,long long>;const long long INF=LLONG_MAX/4;
vector<long long>dijkstra(const vector<vector<Edge>>&g,int src){int n=g.size();if(src<0||src>=n)throw invalid_argument("source out of range");vector<long long>d(n,INF);priority_queue<pair<long long,int>,vector<pair<long long,int>>,greater<pair<long long,int>>>pq;d[src]=0;pq.push({0,src});while(!pq.empty()){auto [du,u]=pq.top();pq.pop();if(du!=d[u])continue;for(auto [v,w]:g[u]){if(w<0)throw invalid_argument("Dijkstra requires non-negative weights");if(du<=INF-w&&du+w<d[v])d[v]=du+w,pq.push({d[v],v});}}return d;}
int main(){vector<vector<Edge>>g(5);auto add=[&](int u,int v,int w){g[u].push_back({v,w});g[v].push_back({u,w});};add(0,1,4);add(0,2,1);add(2,1,2);add(1,3,1);add(2,3,5);for(auto x:dijkstra(g,0))if(x==INF)cout<<"INF ";else cout<<x<<' ';cout<<'\n';}
