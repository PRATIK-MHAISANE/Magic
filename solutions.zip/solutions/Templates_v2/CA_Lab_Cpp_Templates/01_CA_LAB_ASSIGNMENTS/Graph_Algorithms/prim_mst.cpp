/*
==================== ALGORITHM INFO ====================
Name        : Prim's Minimum Spanning Tree
Domain      : Graph Algorithms / Minimum Spanning Tree
CA Lab Link : Assignment 7, Q5 (source document available)
Category    : Assignment-Based
DESCRIPTION
Builds a minimum spanning tree of a connected, undirected weighted graph.
WHEN TO USE
For MST construction; this implementation reports disconnected input as failure.
APPROACH
Grow one tree from a start vertex, repeatedly selecting the cheapest crossing edge.
COMPLEXITY
Time : O((V+E) log V) | Space : O(V+E)
========================================================
*/
#include <bits/stdc++.h>
using namespace std;using Edge=pair<int,long long>;
long long primMST(const vector<vector<Edge>>&g){int n=g.size();if(!n)return 0;vector<bool>used(n);priority_queue<tuple<long long,int,int>,vector<tuple<long long,int,int>>,greater<tuple<long long,int,int>>>pq;pq.push({0,0,-1});long long total=0;int taken=0;while(!pq.empty()){auto [w,u,p]=pq.top();pq.pop();if(used[u])continue;used[u]=true;total+=w;taken++;for(auto [v,c]:g[u])if(!used[v])pq.push({c,v,u});}if(taken!=n)throw runtime_error("graph is disconnected");return total;}
int main(){vector<vector<Edge>>g(4);auto add=[&](int u,int v,int w){g[u].push_back({v,w});g[v].push_back({u,w});};add(0,1,10);add(0,2,6);add(0,3,5);add(1,3,15);add(2,3,4);cout<<primMST(g)<<'\n';}
