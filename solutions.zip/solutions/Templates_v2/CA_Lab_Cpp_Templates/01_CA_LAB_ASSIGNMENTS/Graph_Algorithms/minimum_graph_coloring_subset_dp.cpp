/*
==================== ALGORITHM INFO ====================
Name        : Minimum Graph Coloring (Independent-Set Subset DP)
Domain      : Graph Algorithms / Graph Coloring / Bitmask DP
CA Lab Link : Assignment 7, Q3 Part A
Category    : Assignment-Based
DESCRIPTION
Finds the minimum number of colors (time slots) needed so adjacent vertices receive
 different colors. In exam scheduling, vertices are exams and edges represent conflicts.
WHEN TO USE
For small graphs where exact exponential-time coloring is practical.
APPROACH
Precompute independent subsets. dp[mask] is the minimum number of independent sets
needed to cover mask; choose an independent subset containing a fixed remaining vertex.
COMPLEXITY
Time : O(3^n) after independent-set preprocessing | Space : O(2^n)
NOTE
The assignment's adjacent-slot difficulty penalty (Part B) is a separate optimization
layer and is not implemented in this minimum-coloring template.
========================================================
*/
#include <bits/stdc++.h>
using namespace std;
int minimumColors(const vector<unsigned int>& conflict) {
    int n = conflict.size();
    if (n >= 25) throw invalid_argument("subset DP is intended for small n");
    int N = 1 << n;
    vector<char> independent(N, true);
    for (int mask = 1; mask < N; ++mask) {
        int bit = __builtin_ctz((unsigned)mask);
        int rest = mask & (mask - 1);
        independent[mask] = independent[rest] && ((conflict[bit] & (unsigned)rest) == 0);
    }
    const int INF = n + 1;
    vector<int> dp(N, INF);
    dp[0] = 0;
    for (int mask = 1; mask < N; ++mask) {
        int first = __builtin_ctz((unsigned)mask);
        for (int sub = mask; sub; sub = (sub - 1) & mask) {
            if ((sub & (1 << first)) && independent[sub])
                dp[mask] = min(dp[mask], 1 + dp[mask ^ sub]);
        }
    }
    return dp[N - 1];
}
int main() {
    // 4-cycle: conflicts are 0-1, 1-2, 2-3, 3-0. Two slots suffice.
    vector<unsigned int> conflict = { (1u<<1)|(1u<<3), (1u<<0)|(1u<<2),
                                      (1u<<1)|(1u<<3), (1u<<0)|(1u<<2) };
    cout << "Minimum time slots = " << minimumColors(conflict) << '\n';
}
