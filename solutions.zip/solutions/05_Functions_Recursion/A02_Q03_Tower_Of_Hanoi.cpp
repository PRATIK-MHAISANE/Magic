// Problem: Tower of Hanoi
// Assignment: 2
// Question: 3
// Domain: 05_Functions_Recursion

/* Problem Statement:
Move n disks from peg A to peg C using peg B as the spare, counting and printing every move.

Approach:
Recursively move n-1 disks to spare peg, move the largest disk, then move n-1 disks to target.
*/

#include <bits/stdc++.h>
using namespace std;
long long moveCount = 0;
void hanoi(int n, char from, char to, char aux) {
    if (n == 0) return;
    hanoi(n - 1, from, aux, to);
    moveCount++;
    cout << "Move " << moveCount << ": disk " << n << " from " << from << " to " << to << '\n';
    hanoi(n - 1, aux, to, from);
}
int main() {
    int n;
    cin >> n;
    hanoi(n, 'A', 'C', 'B');
    cout << "Total moves = " << moveCount << "  (2^" << n << " - 1 = " << ((1LL << n) - 1) << ")\n";
    return 0;
}

/* Sample Input & Output:
Input: 3
Output: Total moves = 7
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q03_Tower_Of_Hanoi.cpp -o A02_Q03_Tower_Of_Hanoi.exe && .\A02_Q03_Tower_Of_Hanoi.exe
