// Problem: ATM Cash Dispenser
// Assignment: 5
// Question: 6
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Dispense amount using minimum possible number of currency notes.

Approach:
Greedily pick largest denomination <= remaining amount. (Optimal only for canonical sets).
*/

#include <bits/stdc++.h>
using namespace std;
void dispense(vector<int> denom, int amount) {
    sort(denom.rbegin(), denom.rend());
    int remaining = amount, totalNotes = 0;
    for (int d : denom) {
        if (remaining <= 0) break;
        int count = remaining / d;
        if (count > 0) {
            totalNotes += count;
            remaining -= count * d;
        }
    }
    cout << "Total notes used: " << totalNotes << endl;
}
int main() { dispense({1,2,5,10,20,50,100,200,500}, 1287); return 0; }

/* Sample Input & Output:
Amount: 1287
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A05_Q06_ATM_Cash_Dispenser.cpp -o A05_Q06_ATM_Cash_Dispenser.exe && .\A05_Q06_ATM_Cash_Dispenser.exe
