// Problem: Container Loading
// Assignment: 4
// Question: 1
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Load the maximum possible number of bags into a cargo hold with a strict weight capacity.

Approach:
Greedy choice: to fit as many bags as possible, always take the lightest remaining bag.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int capacity, n;
    cin >> capacity >> n;
    vector<int> w(n);
    for (int i = 0; i < n; i++) cin >> w[i];
    sort(w.begin(), w.end());
    int loaded = 0, totalWeight = 0;
    vector<int> chosen;
    for (int i = 0; i < n; i++) {
        if (totalWeight + w[i] > capacity) break;
        totalWeight += w[i];
        chosen.push_back(w[i]);
        loaded++;
    }
    cout << "Bags loaded = " << loaded << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 400 30 ...
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A04_Q01_Container_Loading.cpp -o A04_Q01_Container_Loading.exe && .\A04_Q01_Container_Loading.exe
