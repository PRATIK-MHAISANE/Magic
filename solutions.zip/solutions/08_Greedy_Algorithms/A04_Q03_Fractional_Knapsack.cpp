// Problem: Fractional Knapsack
// Assignment: 4
// Question: 3
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Maximize total value using divisible (fractional) and indivisible (0/1) commodities.

Approach:
Greedy for divisible items by value per ton. For exact answer, combine with DP on indivisible items.
*/

#include <bits/stdc++.h>
using namespace std;
struct Item {
    string name;
    int qty;
    int value;
    bool divisible;
    double ratio() const { return (double)value / qty; }
};
double fillDivisible(vector<Item> d, int room, vector<pair<string, double>>* taken = nullptr) {
    sort(d.begin(), d.end(), [](const Item& a, const Item& b) { return a.ratio() > b.ratio(); });
    double val = 0;
    for (const Item& x : d) {
        if (room <= 0) break;
        double take = min((double)x.qty, (double)room);
        val += take * x.ratio();
        room -= take;
        if (taken) taken->push_back({x.name, take});
    }
    return val;
}
int main() {
    int capacity, n;
    cin >> capacity >> n;
    vector<Item> items(n);
    for (int i = 0; i < n; i++) {
        string type;
        cin >> items[i].name >> items[i].qty >> items[i].value >> type;
        items[i].divisible = (type == "D");
    }
    // Part 2: exact optimum implementation
    vector<Item> ind, div;
    for (const Item& x : items) (x.divisible ? div : ind).push_back(x);
    int m = ind.size();
    vector<vector<int>> dp(m + 1, vector<int>(capacity + 1, 0));
    for (int i = 1; i <= m; i++)
        for (int c = 0; c <= capacity; c++) {
            dp[i][c] = dp[i - 1][c];
            if (ind[i - 1].qty <= c)
                dp[i][c] = max(dp[i][c], dp[i - 1][c - ind[i - 1].qty] + ind[i - 1].value);
        }
    double best = -1;
    for (int c = 0; c <= capacity; c++) {
        double v = dp[m][c] + fillDivisible(div, capacity - c);
        if (v > best + 1e-9) best = v;
    }
    cout << "Optimal total value = " << best << '\n';
    return 0;
}

/* Sample Input & Output:
Test cases preserved from source.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A04_Q03_Fractional_Knapsack.cpp -o A04_Q03_Fractional_Knapsack.exe && .\A04_Q03_Fractional_Knapsack.exe
