/*
 * ==================================================================
 * ALGORITHM       : Prim's Minimum Spanning Tree (priority queue)
 * DOMAIN          : Graph Algorithms / Greedy
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Grows a minimum spanning tree from a start vertex, always adding the
 *   cheapest edge that connects the tree to a new vertex.
 *
 * WHEN TO USE
 *   Dense or adjacency-list graphs. Only spans the start vertex's
 *   component. Compare with Kruskal, which sorts all edges and works on
 *   forests.
 *
 * APPROACH
 *   1. Put (0, start) in a min-heap keyed by edge weight.
 *   2. Pop the cheapest entry; skip it if its vertex is already in
 *      the tree.
 *   3. Add the vertex (and the edge that reached it) to the tree.
 *   4. Push every edge from the new vertex to a vertex not yet in the
 *      tree.
 *   5. Stop when the heap is empty; if fewer than V vertices were
 *      added, the graph is disconnected.
 *
 * COMPLEXITY
 *   Time : O(E log V)
 *   Space: O(V + E)
 *
 * SAMPLE
 *   Input : n = 5, edges (u,v,w): (0,1,4) (0,2,3) (1,2,1) (1,3,2) (2,3,4)
 *          (3,4,2), start 0;  second graph: n=4, (0,1,1) (2,3,2)
 *   Output:
 *     MST edges: 0-2(3) 2-1(1) 1-3(2) 3-4(2)
 *     MST weight: 8
 *     Reached all vertices: yes
 *     Graph 2 reached all: no, weight from start: 1
 *
 * COMPILE: g++ -std=c++17 prim.cpp -o prim.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Edge { int u, v; ll w; };

struct MSTResult {
    vector<Edge> edges;      // in the order they were added
    ll totalWeight = 0;
    bool reachedAll = false;
};

MSTResult prim(int n, const vector<Edge>& edgeList, int start = 0) {
    if (start < 0 || start >= n) throw invalid_argument("start out of range");
    vector<vector<pair<int, ll>>> adj(n);
    for (const Edge& e : edgeList) {
        adj[e.u].push_back({e.v, e.w});
        adj[e.v].push_back({e.u, e.w});
    }
    typedef tuple<ll, int, int> Item;                    // (weight, vertex, parent)
    priority_queue<Item, vector<Item>, greater<>> pq;
    vector<bool> inTree(n, false);
    MSTResult result;
    int added = 0;
    pq.push({0, start, -1});
    while (!pq.empty()) {
        auto [w, v, parent] = pq.top(); pq.pop();
        if (inTree[v]) continue;
        inTree[v] = true;
        added++;
        if (parent != -1) {
            result.edges.push_back({parent, v, w});
            result.totalWeight += w;
        }
        for (auto [next, cost] : adj[v])
            if (!inTree[next]) pq.push({cost, next, v});
    }
    result.reachedAll = (added == n);
    return result;
}

int main() {
    MSTResult r = prim(5, {{0, 1, 4}, {0, 2, 3}, {1, 2, 1}, {1, 3, 2}, {2, 3, 4}, {3, 4, 2}}, 0);
    cout << "MST edges:";
    for (auto& e : r.edges) cout << ' ' << e.u << '-' << e.v << '(' << e.w << ')';
    cout << "\nMST weight: " << r.totalWeight << '\n';
    cout << "Reached all vertices: " << (r.reachedAll ? "yes" : "no") << '\n';

    MSTResult r2 = prim(4, {{0, 1, 1}, {2, 3, 2}}, 0);
    cout << "Graph 2 reached all: " << (r2.reachedAll ? "yes" : "no") << ", weight from start: " << r2.totalWeight << '\n';
}
