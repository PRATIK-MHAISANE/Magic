/*
 * ==================================================================
 * ALGORITHM       : Topological Sort (Kahn's algorithm)
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Orders the vertices of a directed acyclic graph so that every edge
 *   u->v has u before v. Also detects cycles.
 *
 * WHEN TO USE
 *   Task scheduling, build/dependency order, course prerequisites. Only
 *   exists for DAGs; a cycle means no valid order.
 *
 * APPROACH
 *   1. Compute the in-degree of every vertex.
 *   2. Put all vertices with in-degree 0 into a queue.
 *   3. Pop u, append it to the order, and decrease the in-degree of
 *      each neighbour; push neighbours that reach 0.
 *   4. If the order contains fewer than V vertices, a cycle exists.
 *
 * COMPLEXITY
 *   Time : O(V + E)
 *   Space: O(V)
 *
 * SAMPLE
 *   Input : DAG: n=5, edges 0->1 0->2 1->3 2->3 3->4;  cyclic graph: n=3,
 *          0->1 1->2 2->0
 *   Output:
 *     Order: 0 1 2 3 4
 *     Graph with cycle: cycle detected
 *
 * COMPILE: g++ -std=c++17 topological_sort.cpp -o topological_sort.exe
 */
#include <bits/stdc++.h>
using namespace std;

// Fills 'order'. Returns false if the graph contains a cycle.
bool topologicalSort(const vector<vector<int>>& adj, vector<int>& order) {
    int n = adj.size();
    vector<int> indegree(n, 0);
    for (int u = 0; u < n; u++)
        for (int v : adj[u]) indegree[v]++;
    queue<int> q;
    for (int v = 0; v < n; v++)
        if (indegree[v] == 0) q.push(v);
    order.clear();
    while (!q.empty()) {
        int u = q.front(); q.pop();
        order.push_back(u);
        for (int v : adj[u])
            if (--indegree[v] == 0) q.push(v);
    }
    return (int)order.size() == n;
}

int main() {
    vector<vector<int>> dag(5);
    dag[0] = {1, 2}; dag[1] = {3}; dag[2] = {3}; dag[3] = {4};
    vector<int> order;
    if (topologicalSort(dag, order)) {
        cout << "Order:";
        for (int v : order) cout << ' ' << v;
        cout << '\n';
    }
    vector<vector<int>> cyc = {{1}, {2}, {0}};
    cout << "Graph with cycle: " << (topologicalSort(cyc, order) ? "ordered" : "cycle detected") << '\n';
}
