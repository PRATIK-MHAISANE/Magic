/*
 * ==================================================================
 * ALGORITHM       : Breadth-First Search (BFS)
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Explores a graph level by level from a source using a queue. In an
 *   unweighted graph it gives the fewest-edge distance to every vertex.
 *
 * WHEN TO USE
 *   Shortest path in unweighted graphs, level order, connectivity,
 *   grid/maze shortest path. Limitation: ignores edge weights (use
 *   Dijkstra for weighted graphs).
 *
 * APPROACH
 *   1. dist[src] = 0, all others -1 (unvisited); push src into a
 *      queue.
 *   2. Pop u; for each unvisited neighbour v set dist[v] = dist[u] +
 *      1, parent[v] = u, push v.
 *   3. Repeat until the queue is empty. Vertices left at -1 are
 *      unreachable.
 *   4. Follow parent[] backwards from a target to rebuild the path.
 *
 * COMPLEXITY
 *   Time : O(V + E) with adjacency list
 *   Space: O(V)
 *
 * SAMPLE
 *   Input : n = 6, edges: 0-1 0-2 1-3 2-3 3-4 (vertex 5 isolated)
 *   Output:
 *     Distances: 0 1 1 2 3 -1
 *     Path 0 -> 4: 0 1 3 4
 *     Path 0 -> 5: unreachable
 *
 * COMPILE: g++ -std=c++17 bfs.cpp -o bfs.exe
 */
#include <bits/stdc++.h>
using namespace std;

struct BFSResult {
    vector<int> dist;     // -1 = unreachable
    vector<int> parent;   // -1 = no parent
};

BFSResult bfs(const vector<vector<int>>& adj, int src) {
    int n = adj.size();
    if (src < 0 || src >= n) throw invalid_argument("source out of range");
    BFSResult r{vector<int>(n, -1), vector<int>(n, -1)};
    queue<int> q;
    r.dist[src] = 0;
    q.push(src);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : adj[u]) {
            if (r.dist[v] != -1) continue;
            r.dist[v] = r.dist[u] + 1;
            r.parent[v] = u;
            q.push(v);
        }
    }
    return r;
}

// Path src -> target (empty if unreachable)
vector<int> buildPath(const BFSResult& r, int target) {
    vector<int> path;
    if (r.dist[target] == -1) return path;
    for (int v = target; v != -1; v = r.parent[v]) path.push_back(v);
    reverse(path.begin(), path.end());
    return path;
}

int main() {
    int n = 6;
    vector<vector<int>> adj(n);
    auto addEdge = [&](int a, int b) { adj[a].push_back(b); adj[b].push_back(a); };
    addEdge(0, 1); addEdge(0, 2); addEdge(1, 3); addEdge(2, 3); addEdge(3, 4);

    BFSResult r = bfs(adj, 0);
    cout << "Distances:";
    for (int d : r.dist) cout << ' ' << d;
    cout << '\n';
    for (int target : {4, 5}) {
        auto path = buildPath(r, target);
        cout << "Path 0 -> " << target << ":";
        if (path.empty()) cout << " unreachable";
        for (int v : path) cout << ' ' << v;
        cout << '\n';
    }
}
