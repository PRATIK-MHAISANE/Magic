/*
 * ==================================================================
 * ALGORITHM       : Depth-First Search (DFS)
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Explores as deep as possible along each branch before backtracking.
 *   Implemented recursively and iteratively (explicit stack).
 *
 * WHEN TO USE
 *   Connected components, cycle detection, topological sorting, path
 *   existence, backtracking-style exploration. Limitation: does NOT give
 *   shortest paths.
 *
 * APPROACH
 *   1. Mark the current vertex visited and record it.
 *   2. Recursively visit every unvisited neighbour.
 *   3. Iterative version: push the start on a stack; pop a vertex,
 *      skip if visited, mark it, push neighbours in reverse order so
 *      the visiting order matches the recursive version.
 *   4. Components: start a DFS from every unvisited vertex and count
 *      how many starts were needed.
 *
 * COMPLEXITY
 *   Time : O(V + E)
 *   Space: O(V) for visited + recursion/stack
 *
 * SAMPLE
 *   Input : n = 6, edges: 0-1 0-2 1-3 2-3 3-4 (vertex 5 isolated)
 *   Output:
 *     Recursive DFS from 0: 0 1 3 2 4
 *     Iterative DFS from 0: 0 1 3 2 4
 *     Connected components: 2
 *
 * COMPILE: g++ -std=c++17 dfs.cpp -o dfs.exe
 */
#include <bits/stdc++.h>
using namespace std;

void dfsRecursive(const vector<vector<int>>& adj, int u, vector<bool>& visited, vector<int>& order) {
    visited[u] = true;
    order.push_back(u);
    for (int v : adj[u])
        if (!visited[v]) dfsRecursive(adj, v, visited, order);
}

vector<int> dfsIterative(const vector<vector<int>>& adj, int src) {
    vector<bool> visited(adj.size(), false);
    vector<int> order, stk = {src};
    while (!stk.empty()) {
        int u = stk.back(); stk.pop_back();
        if (visited[u]) continue;
        visited[u] = true;
        order.push_back(u);
        for (int i = (int)adj[u].size() - 1; i >= 0; i--)   // reverse => same order as recursion
            if (!visited[adj[u][i]]) stk.push_back(adj[u][i]);
    }
    return order;
}

int countComponents(const vector<vector<int>>& adj) {
    vector<bool> visited(adj.size(), false);
    vector<int> scratch;
    int components = 0;
    for (size_t s = 0; s < adj.size(); s++)
        if (!visited[s]) { dfsRecursive(adj, s, visited, scratch); components++; }
    return components;
}

int main() {
    int n = 6;
    vector<vector<int>> adj(n);
    auto addEdge = [&](int a, int b) { adj[a].push_back(b); adj[b].push_back(a); };
    addEdge(0, 1); addEdge(0, 2); addEdge(1, 3); addEdge(2, 3); addEdge(3, 4);

    vector<bool> visited(n, false);
    vector<int> order;
    dfsRecursive(adj, 0, visited, order);
    cout << "Recursive DFS from 0:";
    for (int v : order) cout << ' ' << v;
    cout << "\nIterative DFS from 0:";
    for (int v : dfsIterative(adj, 0)) cout << ' ' << v;
    cout << "\nConnected components: " << countComponents(adj) << '\n';
}
