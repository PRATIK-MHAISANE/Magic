/*
 * ==================================================================
 * ALGORITHM       : Kruskal's Minimum Spanning Tree
 * DOMAIN          : Graph Algorithms / Greedy
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Builds a minimum spanning tree (or forest) by taking the cheapest
 *   edges that do not form a cycle, using Union-Find to detect cycles.
 *
 * WHEN TO USE
 *   Sparse graphs, edge-list input. On a disconnected graph it returns a
 *   minimum spanning forest. Compare with Prim, which grows one tree from
 *   a vertex.
 *
 * APPROACH
 *   1. Sort all edges by weight (stable, so ties keep input order).
 *   2. For each edge, if its endpoints are in different Union-Find
 *      sets, take it and unite the sets.
 *   3. Skip edges whose endpoints are already connected (they would
 *      form a cycle).
 *   4. A spanning tree has V-1 edges; fewer means the graph is
 *      disconnected.
 *
 * COMPLEXITY
 *   Time : O(E log E)
 *   Space: O(V + E)
 *
 * SAMPLE
 *   Input : n = 5, edges (u,v,w): (0,1,4) (0,2,3) (1,2,1) (1,3,2) (2,3,4)
 *          (3,4,2);  second graph: n=4, (0,1,1) (2,3,2)
 *   Output:
 *     MST edges: 1-2(1) 1-3(2) 3-4(2) 0-2(3)
 *     MST weight: 8
 *     Connected: yes
 *     Graph 2 forest weight: 3, connected: no
 *
 * COMPILE: g++ -std=c++17 kruskal.cpp -o kruskal.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Edge { int u, v; ll w; };

struct MSTResult {
    vector<Edge> edges;
    ll totalWeight = 0;
    bool connected = false;
};

class DisjointSet {                       // embedded so this file compiles alone
    vector<int> parent, setSize;
public:
    explicit DisjointSet(int n) : parent(n), setSize(n, 1) { iota(parent.begin(), parent.end(), 0); }
    int find(int x) { while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
    bool unite(int a, int b) {
        a = find(a); b = find(b);
        if (a == b) return false;
        if (setSize[a] < setSize[b]) swap(a, b);
        parent[b] = a; setSize[a] += setSize[b];
        return true;
    }
};

MSTResult kruskal(int n, vector<Edge> edges) {
    stable_sort(edges.begin(), edges.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
    DisjointSet dsu(n);
    MSTResult result;
    for (const Edge& e : edges)
        if (dsu.unite(e.u, e.v)) {
            result.edges.push_back(e);
            result.totalWeight += e.w;
        }
    result.connected = ((int)result.edges.size() == n - 1) || n <= 1;
    return result;
}

int main() {
    MSTResult r = kruskal(5, {{0, 1, 4}, {0, 2, 3}, {1, 2, 1}, {1, 3, 2}, {2, 3, 4}, {3, 4, 2}});
    cout << "MST edges:";
    for (auto& e : r.edges) cout << ' ' << e.u << '-' << e.v << '(' << e.w << ')';
    cout << "\nMST weight: " << r.totalWeight << '\n';
    cout << "Connected: " << (r.connected ? "yes" : "no") << '\n';

    MSTResult r2 = kruskal(4, {{0, 1, 1}, {2, 3, 2}});
    cout << "Graph 2 forest weight: " << r2.totalWeight << ", connected: " << (r2.connected ? "yes" : "no") << '\n';
}
