/*
 * ==================================================================
 * ALGORITHM       : Floyd-Warshall All-Pairs Shortest Paths
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Computes the shortest distance between EVERY pair of vertices using
 *   dynamic programming over intermediate vertices.
 *
 * WHEN TO USE
 *   Small graphs (V up to a few hundred) where all-pairs distances are
 *   needed; transitive closure; works with negative edges (not negative
 *   cycles).
 *
 * APPROACH
 *   1. d[i][j] = direct edge weight, d[i][i] = 0, missing edges =
 *      INF.
 *   2. For each intermediate vertex k, for every pair (i, j): d[i][j]
 *      = min(d[i][j], d[i][k] + d[k][j]).
 *   3. The outer loop MUST be over k.
 *   4. After the algorithm, d[i][i] < 0 for some i means a negative
 *      cycle exists.
 *
 * COMPLEXITY
 *   Time : O(V^3)
 *   Space: O(V^2)
 *
 * SAMPLE
 *   Input : n = 4 matrix (INF = no edge): [0 3 INF 7] [8 0 2 INF] [5 INF
 *          0 1] [2 INF INF 0]
 *   Output:
 *     0 3 5 6
 *     5 0 2 3
 *     3 6 0 1
 *     2 5 7 0
 *     Negative cycle: no
 *
 * COMPILE: g++ -std=c++17 floyd_warshall.cpp -o floyd_warshall.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll INF = LLONG_MAX / 4;

// Updates d in place. Returns true if a negative cycle exists.
bool floydWarshall(vector<vector<ll>>& d) {
    int n = d.size();
    for (int k = 0; k < n; k++)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                if (d[i][k] < INF && d[k][j] < INF && d[i][k] + d[k][j] < d[i][j])
                    d[i][j] = d[i][k] + d[k][j];
    for (int i = 0; i < n; i++)
        if (d[i][i] < 0) return true;
    return false;
}

int main() {
    vector<vector<ll>> d = {{0, 3, INF, 7},
                            {8, 0, 2, INF},
                            {5, INF, 0, 1},
                            {2, INF, INF, 0}};
    bool negativeCycle = floydWarshall(d);
    for (auto& row : d) {
        for (size_t j = 0; j < row.size(); j++) {
            if (j) cout << ' ';
            if (row[j] >= INF) cout << "INF"; else cout << row[j];
        }
        cout << '\n';
    }
    cout << "Negative cycle: " << (negativeCycle ? "yes" : "no") << '\n';
}
