/*
 * ==================================================================
 * ALGORITHM       : Bellman-Ford Shortest Path
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Single-source shortest paths that also works with negative edge
 *   weights and can detect a negative cycle reachable from the source.
 *
 * WHEN TO USE
 *   Graphs with negative edges, detecting negative cycles (currency
 *   arbitrage). Slower than Dijkstra, so use Dijkstra when all weights
 *   are non-negative.
 *
 * APPROACH
 *   1. dist[src] = 0, others INF.
 *   2. Repeat V-1 times: relax every edge (u, v, w) if dist[u] is
 *      finite and dist[u] + w < dist[v].
 *   3. A shortest path has at most V-1 edges, so V-1 rounds are
 *      enough; stop early if a round changes nothing.
 *   4. Do one more round: if any edge still relaxes, a negative cycle
 *      is reachable.
 *
 * COMPLEXITY
 *   Time : O(V * E)
 *   Space: O(V)
 *
 * SAMPLE
 *   Input : Graph 1: n=5, directed (0,1,4) (0,2,5) (1,2,-3) (2,3,4),
 *          source 0.  Graph 2: n=3, (0,1,1) (1,2,-3) (2,0,1)
 *   Output:
 *     Distances: 0 4 1 5 INF
 *     Graph 1 negative cycle: no
 *     Graph 2 negative cycle: yes
 *
 * COMPILE: g++ -std=c++17 bellman_ford.cpp -o bellman_ford.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll INF = LLONG_MAX / 4;

struct Edge { int u, v; ll w; };

// Fills dist. Returns true if a negative cycle is reachable from src.
bool bellmanFord(int n, const vector<Edge>& edges, int src, vector<ll>& dist) {
    if (src < 0 || src >= n) throw invalid_argument("source out of range");
    dist.assign(n, INF);
    dist[src] = 0;
    for (int round = 0; round < n - 1; round++) {
        bool changed = false;
        for (const Edge& e : edges)
            if (dist[e.u] < INF && dist[e.u] + e.w < dist[e.v]) {
                dist[e.v] = dist[e.u] + e.w;
                changed = true;
            }
        if (!changed) break;
    }
    for (const Edge& e : edges)
        if (dist[e.u] < INF && dist[e.u] + e.w < dist[e.v]) return true;
    return false;
}

int main() {
    vector<ll> dist;
    vector<Edge> g1 = {{0, 1, 4}, {0, 2, 5}, {1, 2, -3}, {2, 3, 4}};
    bool cycle1 = bellmanFord(5, g1, 0, dist);
    cout << "Distances:";
    for (ll d : dist) { cout << ' '; if (d >= INF) cout << "INF"; else cout << d; }
    cout << "\nGraph 1 negative cycle: " << (cycle1 ? "yes" : "no") << '\n';

    vector<Edge> g2 = {{0, 1, 1}, {1, 2, -3}, {2, 0, 1}};
    cout << "Graph 2 negative cycle: " << (bellmanFord(3, g2, 0, dist) ? "yes" : "no") << '\n';
}
