/*
 * ==================================================================
 * ALGORITHM       : Graph Representation (adjacency list, matrix, edge list)
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   The three standard ways to store a graph in memory, with conversion
 *   between them.
 *
 * WHEN TO USE
 *   Adjacency list for sparse graphs (most problems), matrix for dense
 *   graphs or O(1) edge lookup (Floyd-Warshall), edge list for
 *   Kruskal/Bellman-Ford. This is the first graph topic to learn.
 *
 * APPROACH
 *   1. Adjacency list: vector of vectors, adj[u] holds (v, weight)
 *      for every edge u->v.
 *   2. Undirected edge = store it in both directions.
 *   3. Adjacency matrix: n x n table, m[u][v] = weight (0 means no
 *      edge, so weights must be positive).
 *   4. Edge list: simply a vector of (u, v, w).
 *
 * COMPLEXITY
 *   Time : Build list O(V+E); build matrix O(V^2 + E)
 *   Space: List O(V+E); matrix O(V^2); edge list O(E)
 *
 * SAMPLE
 *   Input : n = 4, undirected edges (0,1,5) (0,2,3) (1,3,2)
 *   Output:
 *     Adjacency list:
 *     0: 1(5) 2(3)
 *     1: 0(5) 3(2)
 *     2: 0(3)
 *     3: 1(2)
 *     Adjacency matrix:
 *     0 5 3 0
 *     5 0 0 2
 *     3 0 0 0
 *     0 2 0 0
 *     Edge list size: 3
 *     Invalid edge rejected: yes
 *
 * COMPILE: g++ -std=c++17 graph_representation.cpp -o graph_representation.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct Edge { int u, v; ll w; };

class Graph {
    int n;
    bool directed;
    vector<vector<pair<int, ll>>> adj;
    vector<Edge> edges;

public:
    Graph(int vertices, bool isDirected) : n(vertices), directed(isDirected), adj(vertices) {}

    void addEdge(int u, int v, ll w = 1) {
        if (u < 0 || u >= n || v < 0 || v >= n) throw invalid_argument("vertex out of range");
        adj[u].push_back({v, w});
        if (!directed) adj[v].push_back({u, w});
        edges.push_back({u, v, w});
    }
    const vector<vector<pair<int, ll>>>& adjacencyList() const { return adj; }
    const vector<Edge>& edgeList() const { return edges; }

    // Matrix form: 0 means "no edge" (assumes positive weights)
    vector<vector<ll>> adjacencyMatrix() const {
        vector<vector<ll>> m(n, vector<ll>(n, 0));
        for (int u = 0; u < n; u++)
            for (auto& [v, w] : adj[u]) m[u][v] = w;
        return m;
    }
};

int main() {
    Graph g(4, false);
    g.addEdge(0, 1, 5); g.addEdge(0, 2, 3); g.addEdge(1, 3, 2);

    cout << "Adjacency list:\n";
    auto& adj = g.adjacencyList();
    for (size_t u = 0; u < adj.size(); u++) {
        cout << u << ":";
        for (auto& [v, w] : adj[u]) cout << ' ' << v << '(' << w << ')';
        cout << '\n';
    }
    cout << "Adjacency matrix:\n";
    for (auto& row : g.adjacencyMatrix()) {
        for (size_t j = 0; j < row.size(); j++) cout << (j ? " " : "") << row[j];
        cout << '\n';
    }
    cout << "Edge list size: " << g.edgeList().size() << '\n';
    bool rejected = false;
    try { g.addEdge(0, 9); } catch (const invalid_argument&) { rejected = true; }
    cout << "Invalid edge rejected: " << (rejected ? "yes" : "no") << '\n';
}
