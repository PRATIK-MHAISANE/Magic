/*
 * ==================================================================
 * ALGORITHM       : Dijkstra's Shortest Path (priority queue)
 * DOMAIN          : Graph Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds the shortest distance from one source to every other vertex in
 *   a weighted graph with NON-negative edge weights.
 *
 * WHEN TO USE
 *   Road networks, routing, any single-source shortest path with
 *   non-negative weights. Limitation: wrong with negative edges (use
 *   Bellman-Ford).
 *
 * APPROACH
 *   1. dist[src] = 0, all others = INF; push (0, src) into a
 *      min-heap.
 *   2. Pop the smallest (d, u). If d > dist[u] it is a stale entry,
 *      skip it.
 *   3. Relax every edge (u, v, w): if dist[u] + w < dist[v], update
 *      dist[v], set parent[v] = u and push.
 *   4. Greedy idea: the first time a vertex is popped its distance is
 *      final.
 *   5. Reject negative weights because the greedy argument breaks.
 *
 * COMPLEXITY
 *   Time : O((V + E) log V)
 *   Space: O(V + E)
 *
 * SAMPLE
 *   Input : n = 5, undirected edges (u,v,w): (0,1,4) (0,2,1) (2,1,2)
 *          (1,3,1) (2,3,5); vertex 4 isolated; source = 0
 *   Output:
 *     Distances from 0: 0 3 1 4 INF
 *     Path 0 -> 3: 0 2 1 3
 *     Negative weight rejected: yes
 *
 * COMPILE: g++ -std=c++17 dijkstra.cpp -o dijkstra.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<vector<pair<int, ll>>> Graph;   // adj[u] = {(v, weight), ...}
const ll INF = LLONG_MAX / 4;

struct DijkstraResult {
    vector<ll> dist;
    vector<int> parent;
};

DijkstraResult dijkstra(const Graph& g, int src) {
    int n = g.size();
    if (src < 0 || src >= n) throw invalid_argument("source out of range");
    DijkstraResult r{vector<ll>(n, INF), vector<int>(n, -1)};
    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<>> pq;
    r.dist[src] = 0;
    pq.push({0, src});
    while (!pq.empty()) {
        auto [d, u] = pq.top(); pq.pop();
        if (d > r.dist[u]) continue;                  // stale entry
        for (auto [v, w] : g[u]) {
            if (w < 0) throw invalid_argument("negative weight not allowed");
            if (d + w < r.dist[v]) {
                r.dist[v] = d + w;
                r.parent[v] = u;
                pq.push({r.dist[v], v});
            }
        }
    }
    return r;
}

vector<int> buildPath(const DijkstraResult& r, int target) {
    vector<int> path;
    if (r.dist[target] >= INF) return path;
    for (int v = target; v != -1; v = r.parent[v]) path.push_back(v);
    reverse(path.begin(), path.end());
    return path;
}

int main() {
    Graph g(5);
    auto addEdge = [&](int a, int b, ll w) { g[a].push_back({b, w}); g[b].push_back({a, w}); };
    addEdge(0, 1, 4); addEdge(0, 2, 1); addEdge(2, 1, 2); addEdge(1, 3, 1); addEdge(2, 3, 5);

    DijkstraResult r = dijkstra(g, 0);
    cout << "Distances from 0:";
    for (ll d : r.dist) { cout << ' '; if (d >= INF) cout << "INF"; else cout << d; }
    cout << "\nPath 0 -> 3:";
    for (int v : buildPath(r, 3)) cout << ' ' << v;
    cout << '\n';

    g[0].push_back({4, -1});
    bool rejected = false;
    try { dijkstra(g, 0); } catch (const invalid_argument&) { rejected = true; }
    cout << "Negative weight rejected: " << (rejected ? "yes" : "no") << '\n';
}
