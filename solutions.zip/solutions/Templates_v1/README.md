# CA Lab C++ Algorithm Template Library

## 1. Overview

Independent, reusable **C++17** reference implementations of common algorithms. Every `.cpp` file:

- has a header (name, domain, description, when to use, approach, complexity, sample input/output),
- keeps the reusable function(s) separate from a small `main()` demonstration,
- compiles on its own (no other file is needed).

> **Important - what is NOT filled in yet.** These templates were written WITHOUT access to the CA Lab assignment documents, the solution files or the official syllabus. The `CA LAB REF` and `CLASSIFICATION` lines in each header, and the *Assignment Reference* column below, are placeholders for you to fill in. Nothing here claims that a given algorithm appears in your syllabus.

## 2. Directory Guide

| Folder | Contents |
|---|---|
| `Basic_Templates/` | Fast IO, number utilities, comparators, Union-Find. |
| `Sorting_and_Searching/` | Elementary sorts, heap/counting sort, merge sort, quick sort, binary search. |
| `Graph_Algorithms/` | Representation, BFS, DFS, shortest paths, MST, topological sort. |
| `Greedy_Algorithms/` | Activity selection, fractional knapsack, Huffman, job sequencing. |
| `Dynamic_Programming/` | Memoization vs tabulation, knapsack, LCS, LIS, edit distance, coin change, matrix chain. |
| `Divide_and_Conquer/` | Max subarray, fast exponentiation. |
| `Backtracking/` | N-Queens, subset sum, permutations and subsets. |
| `String_Algorithms/` | KMP pattern matching. |

## 3. Algorithm Index

| Algorithm | Domain | Assignment Reference | Time Complexity | Space Complexity | File |
|---|---|---|---|---|---|
| Fast Input/Output | Basic Templates | _(fill in)_ | O(n) to read n values | O(n) to store them | `Basic_Templates/fast_io.cpp` |
| Common Number Utilities (gcd, lcm, modPow, isPrime, sieve) | Basic Templates | _(fill in)_ | gcd O(log min(a,b)); modPow O(log exp); isPrime O(sqrt n); sieve O(n log log n) | O(1) for gcd/lcm/modPow/isPrime; O(n) for sieve | `Basic_Templates/common_utilities.cpp` |
| Custom Comparators | Basic Templates | _(fill in)_ | sort with comparator: O(n log n) comparisons | O(1) extra for the comparators | `Basic_Templates/custom_comparators.cpp` |
| Disjoint Set Union (Union-Find) | Basic Templates / Data Structures | _(fill in)_ | O(alpha(n)) amortised per operation (practically constant) | O(n) | `Basic_Templates/disjoint_set_union.cpp` |
| Elementary Sorts + Heap Sort + Counting Sort | Sorting and Searching | _(fill in)_ | Bubble/Selection O(n^2) (bubble best O(n), insertion best O(n)); Insertion O(n^2) worst; Heap O(n log n); Counting O(n + k) | Bubble/Selection/Insertion/Heap O(1); Counting O(k) where k = max value + 1 | `Sorting_and_Searching/sorting_algorithms.cpp` |
| Merge Sort (with inversion count) | Sorting and Searching / Divide and Conquer | _(fill in)_ | Best/Average/Worst O(n log n) | O(n) auxiliary (+ O(log n) recursion) | `Sorting_and_Searching/merge_sort.cpp` |
| Quick Sort (Lomuto partition, middle pivot) | Sorting and Searching / Divide and Conquer | _(fill in)_ | Best/Average O(n log n); Worst O(n^2) | O(log n) average recursion stack; O(n) worst | `Sorting_and_Searching/quick_sort.cpp` |
| Binary Search (+ lower/upper bound, search on answer) | Sorting and Searching | _(fill in)_ | O(log n) | O(1) | `Sorting_and_Searching/binary_search.cpp` |
| Graph Representation (adjacency list, matrix, edge list) | Graph Algorithms | _(fill in)_ | Build list O(V+E); build matrix O(V^2 + E) | List O(V+E); matrix O(V^2); edge list O(E) | `Graph_Algorithms/graph_representation.cpp` |
| Breadth-First Search (BFS) | Graph Algorithms | _(fill in)_ | O(V + E) with adjacency list | O(V) | `Graph_Algorithms/bfs.cpp` |
| Depth-First Search (DFS) | Graph Algorithms | _(fill in)_ | O(V + E) | O(V) for visited + recursion/stack | `Graph_Algorithms/dfs.cpp` |
| Dijkstra's Shortest Path (priority queue) | Graph Algorithms | _(fill in)_ | O((V + E) log V) | O(V + E) | `Graph_Algorithms/dijkstra.cpp` |
| Bellman-Ford Shortest Path | Graph Algorithms | _(fill in)_ | O(V * E) | O(V) | `Graph_Algorithms/bellman_ford.cpp` |
| Floyd-Warshall All-Pairs Shortest Paths | Graph Algorithms | _(fill in)_ | O(V^3) | O(V^2) | `Graph_Algorithms/floyd_warshall.cpp` |
| Kruskal's Minimum Spanning Tree | Graph Algorithms / Greedy | _(fill in)_ | O(E log E) | O(V + E) | `Graph_Algorithms/kruskal.cpp` |
| Prim's Minimum Spanning Tree (priority queue) | Graph Algorithms / Greedy | _(fill in)_ | O(E log V) | O(V + E) | `Graph_Algorithms/prim.cpp` |
| Topological Sort (Kahn's algorithm) | Graph Algorithms | _(fill in)_ | O(V + E) | O(V) | `Graph_Algorithms/topological_sort.cpp` |
| Activity Selection | Greedy Algorithms | _(fill in)_ | O(n log n) (sorting dominates) | O(n) for the result | `Greedy_Algorithms/activity_selection.cpp` |
| Fractional Knapsack | Greedy Algorithms | _(fill in)_ | O(n log n) | O(n) | `Greedy_Algorithms/fractional_knapsack.cpp` |
| Huffman Coding | Greedy Algorithms | _(fill in)_ | O(n log n) | O(n) | `Greedy_Algorithms/huffman_coding.cpp` |
| Job Sequencing with Deadlines | Greedy Algorithms | _(fill in)_ | O(n log n + n * D) where D = max deadline | O(D) | `Greedy_Algorithms/job_sequencing.cpp` |
| Memoization (top-down DP) | Dynamic Programming | _(fill in)_ | Fibonacci O(n); grid paths O(r*c) | O(n) / O(r*c) for cache + recursion stack | `Dynamic_Programming/memoization.cpp` |
| Tabulation (bottom-up DP) | Dynamic Programming | _(fill in)_ | Fibonacci O(n); grid paths O(r*c) | Fibonacci O(n) or O(1) optimised; grid O(c) with a rolling row | `Dynamic_Programming/tabulation.cpp` |
| 0/1 Knapsack | Dynamic Programming | _(fill in)_ | O(n * W) | O(n * W) with reconstruction; O(W) for value only | `Dynamic_Programming/knapsack_01.cpp` |
| Longest Common Subsequence (LCS) | Dynamic Programming | _(fill in)_ | O(n * m) | O(n * m) | `Dynamic_Programming/lcs.cpp` |
| Longest Increasing Subsequence (LIS) | Dynamic Programming | _(fill in)_ | O(n^2) version; O(n log n) version | O(n) | `Dynamic_Programming/lis.cpp` |
| Edit Distance (Levenshtein) | Dynamic Programming | _(fill in)_ | O(n * m) | O(n * m) (O(m) with a rolling row if only the distance is needed) | `Dynamic_Programming/edit_distance.cpp` |
| Coin Change (minimum coins and number of ways) | Dynamic Programming | _(fill in)_ | O(amount * number_of_coins) | O(amount) | `Dynamic_Programming/coin_change.cpp` |
| Matrix Chain Multiplication | Dynamic Programming | _(fill in)_ | O(n^3) | O(n^2) | `Dynamic_Programming/matrix_chain_multiplication.cpp` |
| Maximum Subarray (Divide & Conquer and Kadane) | Divide and Conquer | _(fill in)_ | D&C O(n log n); Kadane O(n) | D&C O(log n) recursion; Kadane O(1) | `Divide_and_Conquer/max_subarray.cpp` |
| Fast Exponentiation (binary exponentiation + matrix Fibonacci) | Divide and Conquer | _(fill in)_ | O(log exp) | O(1) | `Divide_and_Conquer/fast_exponentiation.cpp` |
| N-Queens | Backtracking | _(fill in)_ | O(n!) worst case (heavily pruned in practice) | O(n) | `Backtracking/n_queens.cpp` |
| Subset Sum (backtracking) | Backtracking | _(fill in)_ | O(2^n) worst case | O(n) | `Backtracking/subset_sum.cpp` |
| Generate Permutations and Subsets | Backtracking | _(fill in)_ | Permutations O(n * n!); Subsets O(n * 2^n) | O(n) recursion (excluding output) | `Backtracking/permutations_and_subsets.cpp` |
| Knuth-Morris-Pratt (KMP) Pattern Matching | String Algorithms | _(fill in)_ | O(n + m) | O(m) | `String_Algorithms/kmp.cpp` |

## 4. Algorithm Classification

Use this to sort the algorithms once you have checked your assignments and syllabus. Move each file name into the right list.

- **Assignment-Based Algorithms:** _(fill in)_
- **Syllabus-Based Algorithms:** _(fill in)_
- **Additional Related Algorithms:** _(everything not in the two lists above)_

## 5. Compilation Instructions

Run these from inside the `Template` folder. Replace the path with the file you want.

**Windows CMD**
```bat
g++ -std=c++17 Graph_Algorithms\dijkstra.cpp -o dijkstra.exe
dijkstra.exe
```

**Windows PowerShell**
```powershell
g++ -std=c++17 .\Graph_Algorithms\dijkstra.cpp -o dijkstra.exe
.\dijkstra.exe
```

**Programs that read input** (only `fast_io.cpp` does):
```powershell
"5`n1 2 3 4 5" | .\fast_io.exe
```

Compile every file (PowerShell), to check your setup:
```powershell
Get-ChildItem -Recurse -Filter *.cpp | ForEach-Object { g++ -std=c++17 $_.FullName -o ($_.FullName -replace '\.cpp$','.exe') }
```

Note: the files use `#include <bits/stdc++.h>`, which is available in GCC/MinGW (`g++`) but not in MSVC or Clang on macOS.

## 6. Learning and Revision Guide

Follow this order; each step uses ideas from the earlier ones.

1. **Basics:** `fast_io`, `common_utilities`, `custom_comparators`.
2. **Searching and sorting:** `binary_search` -> `sorting_algorithms` -> `merge_sort` -> `quick_sort` (introduces divide and conquer).
3. **Divide and conquer:** `fast_exponentiation`, `max_subarray`.
4. **Recursion to backtracking:** `permutations_and_subsets` -> `subset_sum` -> `n_queens`.
5. **Dynamic programming:** `memoization` -> `tabulation` -> `knapsack_01` -> `coin_change` -> `lcs` -> `edit_distance` -> `lis` -> `matrix_chain_multiplication`.
6. **Greedy:** `activity_selection` -> `fractional_knapsack` -> `job_sequencing` -> `huffman_coding` (compare `fractional_knapsack` with `knapsack_01`).
7. **Graphs:** `graph_representation` -> `bfs` -> `dfs` -> `topological_sort` -> `dijkstra` -> `bellman_ford` -> `floyd_warshall` -> `disjoint_set_union` -> `kruskal` -> `prim`.
8. **Strings:** `kmp`.

## 7. Quick Viva Comparisons

| Pair | Key difference |
|---|---|
| BFS vs DFS | BFS uses a queue and finds fewest-edge paths; DFS uses a stack/recursion and goes deep first, no shortest-path guarantee. |
| Dijkstra vs Bellman-Ford | Dijkstra is faster (O((V+E) log V)) but needs non-negative weights; Bellman-Ford (O(VE)) allows negative edges and detects negative cycles. |
| Kruskal vs Prim | Kruskal sorts edges and uses Union-Find (good for sparse/edge lists, gives a forest); Prim grows one tree from a vertex with a heap. |
| Greedy vs DP | Greedy commits to a locally best choice and is only correct when that is provably safe (fractional knapsack); DP tries all sub-choices and reuses results (0/1 knapsack). |
| Memoization vs Tabulation | Memoization is top-down recursion with a cache (only needed states); tabulation is bottom-up iteration (no recursion, easier to space-optimise). |
| Merge sort vs Quick sort | Merge: always O(n log n), stable, O(n) extra space. Quick: average O(n log n), in place, worst O(n^2), not stable. |
| Recursion vs Backtracking | Backtracking is recursion that undoes a choice and abandons a branch as soon as it cannot lead to a solution. |

## 8. Verification Status

Run on the machine that generated this library (GCC, Linux):

- All 35 files compiled with `g++ -std=c++17 -Wall -Wextra` with **no warnings**.
- All 35 files were executed and their output matched the sample output written in the file header.
- Randomised checks (thousands of random cases each) compared results with brute force or the C++ standard library for: all five sorts, merge sort (incl. inversion count), quick sort, binary search/lower/upper bound/integer sqrt, LIS, LCS, 0/1 knapsack, coin change, matrix chain, max subarray, fast exponentiation, KMP, N-Queens (n = 1..10), subset sum, activity selection, job sequencing, Huffman, fractional knapsack and edit distance.
- Graph algorithms were cross-checked against each other: Dijkstra = Bellman-Ford = Floyd-Warshall (distances), BFS = Dijkstra on unit weights, Kruskal = Prim (MST weight and connectivity), Kruskal edge count = V - components, topological sort validity and cycle detection against a brute-force transitive closure.
- A bug found during this testing was fixed: `activity_selection.cpp` now breaks finish-time ties by start time.
- Not tested: Windows CMD/PowerShell (commands above are the same g++ invocation, but were not run on Windows); the random-test harness is not included in this folder.
