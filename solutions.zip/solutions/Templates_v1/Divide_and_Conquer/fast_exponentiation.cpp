/*
 * ==================================================================
 * ALGORITHM       : Fast Exponentiation (binary exponentiation + matrix Fibonacci)
 * DOMAIN          : Divide and Conquer
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Computes base^exp in O(log exp) multiplications by repeated squaring.
 *   Applied to numbers (with a modulus) and to 2x2 matrices to get
 *   Fibonacci numbers.
 *
 * WHEN TO USE
 *   Large powers, modular arithmetic, linear recurrences. Naive repeated
 *   multiplication would take O(exp).
 *
 * APPROACH
 *   1. Write exp in binary. Keep result and a running square of the
 *      base.
 *   2. If the current bit of exp is 1, multiply result by the base;
 *      then square the base and shift exp right.
 *   3. Divide and conquer view: x^n = (x^(n/2))^2 (times x if n is
 *      odd).
 *   4. Fibonacci: [[1,1],[1,0]]^n has fib(n) at position [0][1].
 *
 * COMPLEXITY
 *   Time : O(log exp)
 *   Space: O(1)
 *
 * SAMPLE
 *   Input : 2^30 mod 1e9+7; fib(50)
 *   Output:
 *     2^30 mod 1e9+7 = 73741817
 *     fib(50) via matrix = 12586269025
 *     2^0 mod 7 = 1
 *
 * COMPILE: g++ -std=c++17 fast_exponentiation.cpp -o fast_exponentiation.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef array<array<ll, 2>, 2> Matrix2;

ll modPow(ll base, ll exp, ll mod) {
    if (exp < 0 || mod <= 0) throw invalid_argument("exp must be >= 0 and mod > 0");
    ll result = 1 % mod;
    base %= mod;
    if (base < 0) base += mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}

static Matrix2 multiply(const Matrix2& x, const Matrix2& y) {
    Matrix2 z{};
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++) z[i][j] += x[i][k] * y[k][j];
    return z;
}

// fib(n) for 0 <= n <= 90 (the result must fit in long long)
ll fibMatrix(int n) {
    if (n < 0 || n > 90) throw invalid_argument("n must be in [0, 90]");
    Matrix2 result = {{{1, 0}, {0, 1}}};      // identity
    Matrix2 base = {{{1, 1}, {1, 0}}};
    while (n > 0) {
        if (n & 1) result = multiply(result, base);
        n >>= 1;
        if (n) base = multiply(base, base);   // no needless final squaring (avoids overflow)
    }
    return result[0][1];
}

int main() {
    cout << "2^30 mod 1e9+7 = " << modPow(2, 30, 1000000007) << '\n';
    cout << "fib(50) via matrix = " << fibMatrix(50) << '\n';
    cout << "2^0 mod 7 = " << modPow(2, 0, 7) << '\n';
}
