/*
 * ==================================================================
 * ALGORITHM       : Maximum Subarray (Divide & Conquer and Kadane)
 * DOMAIN          : Divide and Conquer
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds the contiguous subarray with the largest sum. Shown two ways:
 *   divide and conquer, and Kadane's linear scan.
 *
 * WHEN TO USE
 *   D&C demonstrates the paradigm and its recurrence; Kadane is the
 *   practical choice. Handles all-negative arrays correctly (answer =
 *   largest element).
 *
 * APPROACH
 *   1. D&C: the best subarray lies entirely in the left half,
 *      entirely in the right half, or crosses the middle.
 *   2. Crossing case: best suffix sum ending at mid + best prefix sum
 *      starting at mid+1.
 *   3. Answer = max(left, right, crossing); recurrence T(n) = 2T(n/2)
 *      + O(n).
 *   4. Kadane: cur = max(a[i], cur + a[i]); best = max(best, cur).
 *
 * COMPLEXITY
 *   Time : D&C O(n log n); Kadane O(n)
 *   Space: D&C O(log n) recursion; Kadane O(1)
 *
 * SAMPLE
 *   Input : -2 1 -3 4 -1 2 1 -5 4
 *   Output:
 *     Divide & conquer: 6
 *     Kadane: 6
 *     All negative: -1
 *
 * COMPILE: g++ -std=c++17 max_subarray.cpp -o max_subarray.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static ll maxCrossing(const vector<int>& a, int lo, int mid, int hi) {
    ll sum = 0, leftBest = LLONG_MIN, rightBest = LLONG_MIN;
    for (int i = mid; i >= lo; i--) { sum += a[i]; leftBest = max(leftBest, sum); }
    sum = 0;
    for (int i = mid + 1; i <= hi; i++) { sum += a[i]; rightBest = max(rightBest, sum); }
    return leftBest + rightBest;
}

static ll maxSubarrayRange(const vector<int>& a, int lo, int hi) {
    if (lo == hi) return a[lo];
    int mid = lo + (hi - lo) / 2;
    return max({maxSubarrayRange(a, lo, mid), maxSubarrayRange(a, mid + 1, hi),
                maxCrossing(a, lo, mid, hi)});
}

ll maxSubarrayDC(const vector<int>& a) {
    if (a.empty()) throw invalid_argument("array must not be empty");
    return maxSubarrayRange(a, 0, (int)a.size() - 1);
}

ll maxSubarrayKadane(const vector<int>& a) {
    if (a.empty()) throw invalid_argument("array must not be empty");
    ll best = a[0], cur = a[0];
    for (size_t i = 1; i < a.size(); i++) {
        cur = max((ll)a[i], cur + a[i]);
        best = max(best, cur);
    }
    return best;
}

int main() {
    vector<int> a = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    cout << "Divide & conquer: " << maxSubarrayDC(a) << '\n';
    cout << "Kadane: " << maxSubarrayKadane(a) << '\n';
    cout << "All negative: " << maxSubarrayKadane({-3, -1, -2}) << '\n';
}
