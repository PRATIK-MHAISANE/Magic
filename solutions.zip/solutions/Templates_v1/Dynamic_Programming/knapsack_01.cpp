/*
 * ==================================================================
 * ALGORITHM       : 0/1 Knapsack
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Chooses a subset of items (each taken whole or not at all) with
 *   maximum total value without exceeding the weight capacity.
 *
 * WHEN TO USE
 *   Budget/capacity selection problems. Greedy by ratio does NOT work for
 *   indivisible items, so DP is used. Pseudo-polynomial: depends on the
 *   numeric value of W.
 *
 * APPROACH
 *   1. dp[i][w] = best value using the first i items with capacity w.
 *   2. If item i does not fit: dp[i][w] = dp[i-1][w].
 *   3. Otherwise: dp[i][w] = max(dp[i-1][w], value[i] + dp[i-1][w -
 *      weight[i]]).
 *   4. Backtrack from dp[n][W]: if dp[i][w] != dp[i-1][w], item i-1
 *      was taken.
 *   5. Space optimisation: a 1-D array iterated with w DEcreasing
 *      gives the same value.
 *
 * COMPLEXITY
 *   Time : O(n * W)
 *   Space: O(n * W) with reconstruction; O(W) for value only
 *
 * SAMPLE
 *   Input : weights 1 3 4 5, values 1 4 5 7, W = 7
 *   Output:
 *     Max value: 9
 *     Chosen items (0-based): 1 2
 *     Space-optimised value: 9
 *     Capacity 0: 0
 *
 * COMPILE: g++ -std=c++17 knapsack_01.cpp -o knapsack_01.exe
 */
#include <bits/stdc++.h>
using namespace std;

struct KnapsackResult {
    int bestValue = 0;
    vector<int> chosen;          // 0-based indices, ascending
};

KnapsackResult knapsack01(const vector<int>& weight, const vector<int>& value, int capacity) {
    if (weight.size() != value.size()) throw invalid_argument("size mismatch");
    if (capacity < 0) throw invalid_argument("capacity must be >= 0");
    int n = weight.size();
    for (int w : weight) if (w < 0) throw invalid_argument("negative weight");
    vector<vector<int>> dp(n + 1, vector<int>(capacity + 1, 0));
    for (int i = 1; i <= n; i++)
        for (int w = 0; w <= capacity; w++) {
            dp[i][w] = dp[i - 1][w];
            if (weight[i - 1] <= w)
                dp[i][w] = max(dp[i][w], value[i - 1] + dp[i - 1][w - weight[i - 1]]);
        }
    KnapsackResult r;
    r.bestValue = dp[n][capacity];
    for (int i = n, w = capacity; i >= 1; i--)
        if (dp[i][w] != dp[i - 1][w]) {                 // item i-1 was taken
            r.chosen.push_back(i - 1);
            w -= weight[i - 1];
        }
    reverse(r.chosen.begin(), r.chosen.end());
    return r;
}

int knapsack01Optimised(const vector<int>& weight, const vector<int>& value, int capacity) {
    vector<int> dp(capacity + 1, 0);
    for (size_t i = 0; i < weight.size(); i++)
        for (int w = capacity; w >= weight[i]; w--)      // downwards: each item used once
            dp[w] = max(dp[w], value[i] + dp[w - weight[i]]);
    return dp[capacity];
}

int main() {
    vector<int> wt = {1, 3, 4, 5}, val = {1, 4, 5, 7};
    KnapsackResult r = knapsack01(wt, val, 7);
    cout << "Max value: " << r.bestValue << '\n';
    cout << "Chosen items (0-based):";
    for (int i : r.chosen) cout << ' ' << i;
    cout << "\nSpace-optimised value: " << knapsack01Optimised(wt, val, 7) << '\n';
    cout << "Capacity 0: " << knapsack01(wt, val, 0).bestValue << '\n';
}
