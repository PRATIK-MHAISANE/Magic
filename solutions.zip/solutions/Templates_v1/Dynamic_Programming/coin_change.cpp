/*
 * ==================================================================
 * ALGORITHM       : Coin Change (minimum coins and number of ways)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Two classic unbounded-knapsack style problems: the fewest coins to
 *   make an amount, and the number of different combinations that make
 *   it.
 *
 * WHEN TO USE
 *   Currency problems. Greedy (largest coin first) only works for special
 *   coin systems; DP works for any set of positive coins.
 *
 * APPROACH
 *   1. Min coins: dp[a] = 1 + min(dp[a - c]) over coins c <= a; dp[0]
 *      = 0; unreachable stays INF.
 *   2. Ways: dp[0] = 1; for each coin (OUTER loop) and each amount a
 *      >= c: dp[a] += dp[a - c].
 *   3. Coin loop outside counts combinations; amount loop outside
 *      would count ordered sequences.
 *
 * COMPLEXITY
 *   Time : O(amount * number_of_coins)
 *   Space: O(amount)
 *
 * SAMPLE
 *   Input : coins {1,2,5}, amount 11 (min) and 5 (ways); coins {2},
 *          amount 3
 *   Output:
 *     Min coins for 11 using {1,2,5}: 3
 *     Ways to make 5 using {1,2,5}: 4
 *     Min coins for 3 using {2}: impossible
 *
 * COMPILE: g++ -std=c++17 coin_change.cpp -o coin_change.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Returns -1 if the amount cannot be formed.
int minCoins(const vector<int>& coins, int amount) {
    if (amount < 0) throw invalid_argument("amount must be >= 0");
    for (int c : coins) if (c <= 0) throw invalid_argument("coins must be positive");
    const int INF = INT_MAX;
    vector<int> dp(amount + 1, INF);
    dp[0] = 0;
    for (int a = 1; a <= amount; a++)
        for (int c : coins)
            if (c <= a && dp[a - c] != INF) dp[a] = min(dp[a], dp[a - c] + 1);
    return dp[amount] == INF ? -1 : dp[amount];
}

// Number of combinations (order does not matter)
ll countWays(const vector<int>& coins, int amount) {
    if (amount < 0) throw invalid_argument("amount must be >= 0");
    for (int c : coins) if (c <= 0) throw invalid_argument("coins must be positive");
    vector<ll> dp(amount + 1, 0);
    dp[0] = 1;
    for (int c : coins)
        for (int a = c; a <= amount; a++) dp[a] += dp[a - c];
    return dp[amount];
}

int main() {
    cout << "Min coins for 11 using {1,2,5}: " << minCoins({1, 2, 5}, 11) << '\n';
    cout << "Ways to make 5 using {1,2,5}: " << countWays({1, 2, 5}, 5) << '\n';
    int r = minCoins({2}, 3);
    cout << "Min coins for 3 using {2}: " << (r == -1 ? string("impossible") : to_string(r)) << '\n';
}
