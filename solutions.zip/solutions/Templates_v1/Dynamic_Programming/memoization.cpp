/*
 * ==================================================================
 * ALGORITHM       : Memoization (top-down DP)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Recursion plus a cache: each distinct subproblem is solved once and
 *   its answer is stored for reuse.
 *
 * WHEN TO USE
 *   When the recursive formulation is natural and overlapping subproblems
 *   exist (Fibonacci, grid paths). Only the needed states are computed.
 *   Limitation: recursion depth and call overhead.
 *
 * APPROACH
 *   1. Write the plain recursive solution.
 *   2. Before computing a state, look it up in the cache; if present
 *      return it.
 *   3. Otherwise compute, store in the cache, then return.
 *   4. Examples here: Fibonacci and unique paths in an r x c grid.
 *
 * COMPLEXITY
 *   Time : Fibonacci O(n); grid paths O(r*c)
 *   Space: O(n) / O(r*c) for cache + recursion stack
 *
 * SAMPLE
 *   Input : fib(40); grid 3 x 7
 *   Output:
 *     fib(40) = 102334155
 *     Unique paths in 3x7 grid = 28
 *
 * COMPILE: g++ -std=c++17 memoization.cpp -o memoization.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll fibMemo(int n, unordered_map<int, ll>& memo) {
    if (n < 0) throw invalid_argument("n must be >= 0");
    if (n <= 1) return n;
    auto it = memo.find(n);
    if (it != memo.end()) return it->second;          // cache hit
    return memo[n] = fibMemo(n - 1, memo) + fibMemo(n - 2, memo);
}

// Moves allowed: right or down, from top-left to bottom-right of an r x c grid
ll gridPathsMemo(int r, int c, map<pair<int, int>, ll>& memo) {
    if (r < 1 || c < 1) throw invalid_argument("grid size must be >= 1");
    if (r == 1 || c == 1) return 1;
    auto key = make_pair(r, c);
    auto it = memo.find(key);
    if (it != memo.end()) return it->second;
    return memo[key] = gridPathsMemo(r - 1, c, memo) + gridPathsMemo(r, c - 1, memo);
}

int main() {
    unordered_map<int, ll> fibCache;
    cout << "fib(40) = " << fibMemo(40, fibCache) << '\n';
    map<pair<int, int>, ll> gridCache;
    cout << "Unique paths in 3x7 grid = " << gridPathsMemo(3, 7, gridCache) << '\n';
}
