/*
 * ==================================================================
 * ALGORITHM       : Matrix Chain Multiplication
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds the cheapest way to parenthesise a product of matrices A1 x A2
 *   x ... x An, where the cost is the number of scalar multiplications.
 *
 * WHEN TO USE
 *   Classic interval DP. The order of multiplication does not change the
 *   result but changes the cost dramatically.
 *
 * APPROACH
 *   1. dims[i-1] x dims[i] is the size of matrix Ai, so n matrices
 *      need n+1 numbers.
 *   2. m[i][j] = minimum cost to multiply Ai..Aj; m[i][i] = 0.
 *   3. Try every split k in [i, j-1]: m[i][j] = min(m[i][k] +
 *      m[k+1][j] + dims[i-1]*dims[k]*dims[j]).
 *   4. Fill by increasing chain length; store the best split to print
 *      the parenthesisation.
 *
 * COMPLEXITY
 *   Time : O(n^3)
 *   Space: O(n^2)
 *
 * SAMPLE
 *   Input : dims = 40 20 30 10 30  (A1:40x20, A2:20x30, A3:30x10,
 *          A4:10x30)
 *   Output:
 *     Minimum multiplications: 26000
 *     Parenthesization: ((A1(A2A3))A4)
 *
 * COMPILE: g++ -std=c++17 matrix_chain_multiplication.cpp -o matrix_chain_multiplication.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

static string buildParens(const vector<vector<int>>& split, int i, int j) {
    if (i == j) return "A" + to_string(i);
    int k = split[i][j];
    return "(" + buildParens(split, i, k) + buildParens(split, k + 1, j) + ")";
}

// dims has n+1 entries for n matrices. Matrices are numbered 1..n.
ll matrixChain(const vector<int>& dims, string& parenthesization) {
    if (dims.size() < 2) throw invalid_argument("need at least one matrix (2 dimensions)");
    int n = dims.size() - 1;
    vector<vector<ll>> m(n + 1, vector<ll>(n + 1, 0));
    vector<vector<int>> split(n + 1, vector<int>(n + 1, 0));
    for (int len = 2; len <= n; len++)
        for (int i = 1; i + len - 1 <= n; i++) {
            int j = i + len - 1;
            m[i][j] = LLONG_MAX;
            for (int k = i; k < j; k++) {
                ll cost = m[i][k] + m[k + 1][j] + (ll)dims[i - 1] * dims[k] * dims[j];
                if (cost < m[i][j]) { m[i][j] = cost; split[i][j] = k; }
            }
        }
    parenthesization = buildParens(split, 1, n);
    return m[1][n];
}

int main() {
    string order;
    ll cost = matrixChain({40, 20, 30, 10, 30}, order);
    cout << "Minimum multiplications: " << cost << '\n';
    cout << "Parenthesization: " << order << '\n';
}
