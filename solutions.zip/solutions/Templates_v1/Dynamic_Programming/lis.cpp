/*
 * ==================================================================
 * ALGORITHM       : Longest Increasing Subsequence (LIS)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds the longest subsequence whose elements are in strictly
 *   increasing order. Two versions: O(n^2) DP with reconstruction and O(n
 *   log n) length-only.
 *
 * WHEN TO USE
 *   Use O(n^2) for exams and to print the sequence; use O(n log n) for
 *   large n when only the length is needed.
 *
 * APPROACH
 *   1. O(n^2): dp[i] = longest increasing subsequence ending at i = 1
 *      + max(dp[j]) over j < i with a[j] < a[i]; store prev[i] to
 *      rebuild.
 *   2. O(n log n): keep 'tails', where tails[k] = smallest possible
 *      last value of an increasing subsequence of length k+1.
 *   3. For each x, lower_bound in tails: replace that position, or
 *      append if x is larger than all.
 *   4. tails itself is NOT necessarily a valid LIS; only its size is
 *      the answer.
 *
 * COMPLEXITY
 *   Time : O(n^2) version; O(n log n) version
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : 10 9 2 5 3 7 101 18
 *   Output:
 *     LIS length (O(n log n)): 4
 *     One LIS (O(n^2)): 2 5 7 101
 *     Empty input: 0
 *
 * COMPILE: g++ -std=c++17 lis.cpp -o lis.exe
 */
#include <bits/stdc++.h>
using namespace std;

vector<int> lisQuadratic(const vector<int>& a) {
    int n = a.size();
    if (n == 0) return {};
    vector<int> dp(n, 1), prev(n, -1);
    int best = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++)
            if (a[j] < a[i] && dp[j] + 1 > dp[i]) { dp[i] = dp[j] + 1; prev[i] = j; }
        if (dp[i] > dp[best]) best = i;
    }
    vector<int> seq;
    for (int i = best; i != -1; i = prev[i]) seq.push_back(a[i]);
    reverse(seq.begin(), seq.end());
    return seq;
}

int lisLengthFast(const vector<int>& a) {
    vector<int> tails;
    for (int x : a) {
        auto it = lower_bound(tails.begin(), tails.end(), x);   // strictly increasing
        if (it == tails.end()) tails.push_back(x);
        else *it = x;
    }
    return tails.size();
}

int main() {
    vector<int> a = {10, 9, 2, 5, 3, 7, 101, 18};
    cout << "LIS length (O(n log n)): " << lisLengthFast(a) << '\n';
    cout << "One LIS (O(n^2)):";
    for (int x : lisQuadratic(a)) cout << ' ' << x;
    cout << "\nEmpty input: " << lisLengthFast({}) << '\n';
}
