/*
 * ==================================================================
 * ALGORITHM       : Longest Common Subsequence (LCS)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds the longest sequence of characters that appears in both strings
 *   in the same order (not necessarily contiguous).
 *
 * WHEN TO USE
 *   Diff tools, DNA comparison, similarity measures. Not the same as
 *   longest common SUBSTRING, which must be contiguous.
 *
 * APPROACH
 *   1. dp[i][j] = LCS length of the first i characters of A and first
 *      j characters of B.
 *   2. If A[i-1] == B[j-1]: dp[i][j] = dp[i-1][j-1] + 1.
 *   3. Else: dp[i][j] = max(dp[i-1][j], dp[i][j-1]).
 *   4. Backtrack from dp[n][m] to rebuild one LCS string.
 *
 * COMPLEXITY
 *   Time : O(n * m)
 *   Space: O(n * m)
 *
 * SAMPLE
 *   Input : A = AGGTAB, B = GXTXAYB
 *   Output:
 *     LCS length: 4
 *     LCS: GTAB
 *     Empty input LCS length: 0
 *
 * COMPILE: g++ -std=c++17 lcs.cpp -o lcs.exe
 */
#include <bits/stdc++.h>
using namespace std;

// Returns one longest common subsequence of a and b.
string lcs(const string& a, const string& b) {
    int n = a.size(), m = b.size();
    vector<vector<int>> dp(n + 1, vector<int>(m + 1, 0));
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            dp[i][j] = (a[i - 1] == b[j - 1]) ? dp[i - 1][j - 1] + 1
                                              : max(dp[i - 1][j], dp[i][j - 1]);
    string result;
    int i = n, j = m;
    while (i > 0 && j > 0) {
        if (a[i - 1] == b[j - 1]) { result.push_back(a[i - 1]); i--; j--; }
        else if (dp[i - 1][j] >= dp[i][j - 1]) i--;
        else j--;
    }
    reverse(result.begin(), result.end());
    return result;
}

int main() {
    string s = lcs("AGGTAB", "GXTXAYB");
    cout << "LCS length: " << s.size() << '\n';
    cout << "LCS: " << s << '\n';
    cout << "Empty input LCS length: " << lcs("", "abc").size() << '\n';
}
