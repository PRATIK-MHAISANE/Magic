/*
 * ==================================================================
 * ALGORITHM       : Edit Distance (Levenshtein)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Minimum number of single-character insertions, deletions and
 *   substitutions needed to turn one string into another.
 *
 * WHEN TO USE
 *   Spell checking, DNA alignment, string similarity.
 *
 * APPROACH
 *   1. dp[i][j] = edit distance between the first i chars of A and
 *      first j chars of B.
 *   2. Base: dp[i][0] = i (delete all), dp[0][j] = j (insert all).
 *   3. If A[i-1] == B[j-1]: dp[i][j] = dp[i-1][j-1].
 *   4. Else: dp[i][j] = 1 + min(delete dp[i-1][j], insert dp[i][j-1],
 *      replace dp[i-1][j-1]).
 *
 * COMPLEXITY
 *   Time : O(n * m)
 *   Space: O(n * m) (O(m) with a rolling row if only the distance is
 *          needed)
 *
 * SAMPLE
 *   Input : kitten -> sitting; "" -> abc; equal strings
 *   Output:
 *     kitten -> sitting: 3
 *     "" -> abc: 3
 *     same strings: 0
 *
 * COMPILE: g++ -std=c++17 edit_distance.cpp -o edit_distance.exe
 */
#include <bits/stdc++.h>
using namespace std;

int editDistance(const string& a, const string& b) {
    int n = a.size(), m = b.size();
    vector<vector<int>> dp(n + 1, vector<int>(m + 1, 0));
    for (int i = 0; i <= n; i++) dp[i][0] = i;
    for (int j = 0; j <= m; j++) dp[0][j] = j;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            if (a[i - 1] == b[j - 1]) dp[i][j] = dp[i - 1][j - 1];
            else dp[i][j] = 1 + min({dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]});
        }
    return dp[n][m];
}

int main() {
    cout << "kitten -> sitting: " << editDistance("kitten", "sitting") << '\n';
    cout << "\"\" -> abc: " << editDistance("", "abc") << '\n';
    cout << "same strings: " << editDistance("abc", "abc") << '\n';
}
