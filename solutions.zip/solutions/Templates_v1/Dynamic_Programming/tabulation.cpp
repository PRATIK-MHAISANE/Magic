/*
 * ==================================================================
 * ALGORITHM       : Tabulation (bottom-up DP)
 * DOMAIN          : Dynamic Programming
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Fills a table iteratively from the smallest subproblems up to the
 *   final answer; no recursion.
 *
 * WHEN TO USE
 *   When all states are needed or recursion depth could be large. Allows
 *   space optimisation (keep only the last row/values).
 *
 * APPROACH
 *   1. Define the state and the base cases.
 *   2. Decide an order in which every dependency is already computed
 *      (small to large).
 *   3. Fill the table with the recurrence.
 *   4. Optionally keep only the part of the table still needed
 *      (Fibonacci: two variables).
 *
 * COMPLEXITY
 *   Time : Fibonacci O(n); grid paths O(r*c)
 *   Space: Fibonacci O(n) or O(1) optimised; grid O(c) with a rolling row
 *
 * SAMPLE
 *   Input : fib(40); grid 3 x 7
 *   Output:
 *     fib(40) tabulation = 102334155
 *     fib(40) O(1) space = 102334155
 *     Unique paths in 3x7 grid = 28
 *
 * COMPILE: g++ -std=c++17 tabulation.cpp -o tabulation.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll fibTabulation(int n) {
    if (n < 0) throw invalid_argument("n must be >= 0");
    vector<ll> dp(max(n + 1, 2));
    dp[0] = 0; dp[1] = 1;
    for (int i = 2; i <= n; i++) dp[i] = dp[i - 1] + dp[i - 2];
    return dp[n];
}

ll fibConstantSpace(int n) {
    if (n < 0) throw invalid_argument("n must be >= 0");
    ll prev = 0, cur = 1;
    for (int i = 0; i < n; i++) { ll next = prev + cur; prev = cur; cur = next; }
    return prev;
}

// Rolling single row: dp[j] = paths to reach column j in the current row
ll gridPathsTabulation(int r, int c) {
    if (r < 1 || c < 1) throw invalid_argument("grid size must be >= 1");
    vector<ll> dp(c, 1);
    for (int i = 1; i < r; i++)
        for (int j = 1; j < c; j++) dp[j] += dp[j - 1];
    return dp[c - 1];
}

int main() {
    cout << "fib(40) tabulation = " << fibTabulation(40) << '\n';
    cout << "fib(40) O(1) space = " << fibConstantSpace(40) << '\n';
    cout << "Unique paths in 3x7 grid = " << gridPathsTabulation(3, 7) << '\n';
}
