/*
 * ==================================================================
 * ALGORITHM       : Elementary Sorts + Heap Sort + Counting Sort
 * DOMAIN          : Sorting and Searching
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Five classic sorting algorithms in one file for comparison: bubble,
 *   selection, insertion, heap and counting sort.
 *
 * WHEN TO USE
 *   Bubble/selection/insertion are simple and good for tiny or nearly
 *   sorted data (insertion). Heap sort guarantees O(n log n) in place.
 *   Counting sort is linear when values are small non-negative integers.
 *
 * APPROACH
 *   1. Bubble: repeatedly swap adjacent out-of-order pairs; stop
 *      early if a pass makes no swap.
 *   2. Selection: pick the minimum of the unsorted part and put it at
 *      the front.
 *   3. Insertion: insert each element into the sorted prefix by
 *      shifting larger ones right.
 *   4. Heap: build a max-heap, then repeatedly move the root to the
 *      end and restore the heap.
 *   5. Counting: count occurrences of each value, then write values
 *      back in order (values must be >= 0).
 *
 * COMPLEXITY
 *   Time : Bubble/Selection O(n^2) (bubble best O(n), insertion best
 *          O(n)); Insertion O(n^2) worst; Heap O(n log n); Counting O(n +
 *          k)
 *   Space: Bubble/Selection/Insertion/Heap O(1); Counting O(k) where k =
 *          max value + 1
 *
 * SAMPLE
 *   Input : 64 25 12 22 11 25
 *   Output:
 *     Bubble    : 11 12 22 25 25 64
 *     Selection : 11 12 22 25 25 64
 *     Insertion : 11 12 22 25 25 64
 *     Heap      : 11 12 22 25 25 64
 *     Counting  : 11 12 22 25 25 64
 *     Empty array sorted: 0 elements
 *     Counting sort rejects negatives: yes
 *
 * COMPILE: g++ -std=c++17 sorting_algorithms.cpp -o sorting_algorithms.exe
 */
#include <bits/stdc++.h>
using namespace std;

void bubbleSort(vector<int>& a) {
    int n = a.size();
    for (int pass = 0; pass + 1 < n; pass++) {
        bool swapped = false;
        for (int j = 0; j + 1 < n - pass; j++)
            if (a[j] > a[j + 1]) { swap(a[j], a[j + 1]); swapped = true; }
        if (!swapped) break;                // already sorted
    }
}

void selectionSort(vector<int>& a) {
    int n = a.size();
    for (int i = 0; i + 1 < n; i++) {
        int minIndex = i;
        for (int j = i + 1; j < n; j++)
            if (a[j] < a[minIndex]) minIndex = j;
        swap(a[i], a[minIndex]);
    }
}

void insertionSort(vector<int>& a) {
    for (int i = 1; i < (int)a.size(); i++) {
        int key = a[i], j = i - 1;
        while (j >= 0 && a[j] > key) { a[j + 1] = a[j]; j--; }
        a[j + 1] = key;
    }
}

static void siftDown(vector<int>& a, int n, int i) {
    while (true) {
        int largest = i, l = 2 * i + 1, r = 2 * i + 2;
        if (l < n && a[l] > a[largest]) largest = l;
        if (r < n && a[r] > a[largest]) largest = r;
        if (largest == i) return;
        swap(a[i], a[largest]);
        i = largest;
    }
}

void heapSort(vector<int>& a) {
    int n = a.size();
    for (int i = n / 2 - 1; i >= 0; i--) siftDown(a, n, i);   // build max-heap
    for (int end = n - 1; end > 0; end--) {
        swap(a[0], a[end]);
        siftDown(a, end, 0);
    }
}

// Only for non-negative values. Returns false (array untouched) otherwise.
bool countingSort(vector<int>& a) {
    if (a.empty()) return true;
    int maxValue = *max_element(a.begin(), a.end());
    if (*min_element(a.begin(), a.end()) < 0) return false;
    vector<int> count(maxValue + 1, 0);
    for (int x : a) count[x]++;
    int idx = 0;
    for (int v = 0; v <= maxValue; v++)
        while (count[v]-- > 0) a[idx++] = v;
    return true;
}

static void show(const string& label, const vector<int>& a) {
    cout << label << ":";
    for (int x : a) cout << ' ' << x;
    cout << '\n';
}

int main() {
    const vector<int> data = {64, 25, 12, 22, 11, 25};
    vector<int> a;
    a = data; bubbleSort(a);    show("Bubble    ", a);
    a = data; selectionSort(a); show("Selection ", a);
    a = data; insertionSort(a); show("Insertion ", a);
    a = data; heapSort(a);      show("Heap      ", a);
    a = data; countingSort(a);  show("Counting  ", a);
    vector<int> empty;
    heapSort(empty); bubbleSort(empty);
    cout << "Empty array sorted: " << empty.size() << " elements\n";
    vector<int> bad = {3, -1};
    cout << "Counting sort rejects negatives: " << (countingSort(bad) ? "no" : "yes") << '\n';
}
