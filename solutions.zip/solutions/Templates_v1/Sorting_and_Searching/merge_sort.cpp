/*
 * ==================================================================
 * ALGORITHM       : Merge Sort (with inversion count)
 * DOMAIN          : Sorting and Searching / Divide and Conquer
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Splits the array in halves, sorts each half recursively, then merges
 *   the two sorted halves. The same merge step also counts inversions.
 *
 * WHEN TO USE
 *   When guaranteed O(n log n) and stability are needed, or for
 *   external/linked-list sorting. Limitation: needs O(n) extra memory.
 *
 * APPROACH
 *   1. If the range has 0 or 1 elements it is sorted.
 *   2. Sort the left half and the right half recursively.
 *   3. Merge: repeatedly take the smaller front element (take from
 *      the left on ties so the sort is stable).
 *   4. Inversions: whenever an element is taken from the right half,
 *      it jumps over all remaining left elements, so add that many.
 *
 * COMPLEXITY
 *   Time : Best/Average/Worst O(n log n)
 *   Space: O(n) auxiliary (+ O(log n) recursion)
 *
 * SAMPLE
 *   Input : 38 27 43 3 9 82 10
 *   Output:
 *     Sorted: 3 9 10 27 38 43 82
 *     Inversions: 11
 *     Empty array: 0 elements
 *
 * COMPILE: g++ -std=c++17 merge_sort.cpp -o merge_sort.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

// Sorts a[lo..hi] and returns the number of inversions in it.
ll mergeSortCount(vector<int>& a, vector<int>& tmp, int lo, int hi) {
    if (lo >= hi) return 0;
    int mid = lo + (hi - lo) / 2;
    ll inversions = mergeSortCount(a, tmp, lo, mid) + mergeSortCount(a, tmp, mid + 1, hi);

    int i = lo, j = mid + 1, k = lo;
    while (i <= mid && j <= hi) {
        if (a[i] <= a[j]) tmp[k++] = a[i++];           // <= keeps it stable
        else { tmp[k++] = a[j++]; inversions += mid - i + 1; }
    }
    while (i <= mid) tmp[k++] = a[i++];
    while (j <= hi) tmp[k++] = a[j++];
    for (int t = lo; t <= hi; t++) a[t] = tmp[t];
    return inversions;
}

// Sorts the whole vector; returns the inversion count.
ll mergeSort(vector<int>& a) {
    if (a.size() < 2) return 0;
    vector<int> tmp(a.size());
    return mergeSortCount(a, tmp, 0, (int)a.size() - 1);
}

int main() {
    vector<int> a = {38, 27, 43, 3, 9, 82, 10};
    ll inv = mergeSort(a);
    cout << "Sorted:";
    for (int x : a) cout << ' ' << x;
    cout << "\nInversions: " << inv << '\n';
    vector<int> empty;
    mergeSort(empty);
    cout << "Empty array: " << empty.size() << " elements\n";
}
