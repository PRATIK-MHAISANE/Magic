/*
 * ==================================================================
 * ALGORITHM       : Binary Search (+ lower/upper bound, search on answer)
 * DOMAIN          : Sorting and Searching
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds a value in a SORTED array by repeatedly halving the search
 *   range. lowerBound/upperBound give the first position >= key / > key.
 *
 * WHEN TO USE
 *   Searching sorted data, counting occurrences, and 'search on the
 *   answer' problems (for example integer square root). Limitation: data
 *   must be sorted (or the condition monotonic).
 *
 * APPROACH
 *   1. Keep a range [lo, hi]; compare the middle element with the
 *      key.
 *   2. If equal return; if smaller discard the left half; otherwise
 *      discard the right half.
 *   3. lowerBound: do not stop on equality, keep shrinking to the
 *      left to find the first position >= key.
 *   4. Count of key = upperBound(key) - lowerBound(key).
 *   5. Search on answer: binary search the value x for which a
 *      monotonic check changes from true to false.
 *
 * COMPLEXITY
 *   Time : O(log n)
 *   Space: O(1)
 *
 * SAMPLE
 *   Input : a = 1 3 3 3 5 8
 *   Output:
 *     search 5 -> 4
 *     search 4 -> -1
 *     lowerBound(3) = 1, upperBound(3) = 4, count = 3
 *     isqrt(99) = 9, isqrt(100) = 10
 *     Search in empty array -> -1
 *
 * COMPILE: g++ -std=c++17 binary_search.cpp -o binary_search.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int binarySearch(const vector<int>& a, int key) {       // index or -1
    int lo = 0, hi = (int)a.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] == key) return mid;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid - 1;
    }
    return -1;
}

int lowerBound(const vector<int>& a, int key) {          // first index with a[i] >= key
    int lo = 0, hi = a.size();
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] < key) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

int upperBound(const vector<int>& a, int key) {          // first index with a[i] > key
    int lo = 0, hi = a.size();
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (a[mid] <= key) lo = mid + 1;
        else hi = mid;
    }
    return lo;
}

// Search on the answer: largest x with x*x <= n. Returns -1 for n < 0.
ll integerSqrt(ll n) {
    if (n < 0) return -1;
    ll lo = 0, hi = min(n, 3037000499LL);                // 3037000499^2 fits in ll
    while (lo < hi) {
        ll mid = lo + (hi - lo + 1) / 2;
        if (mid * mid <= n) lo = mid;
        else hi = mid - 1;
    }
    return lo;
}

int main() {
    vector<int> a = {1, 3, 3, 3, 5, 8};
    cout << "search 5 -> " << binarySearch(a, 5) << '\n';
    cout << "search 4 -> " << binarySearch(a, 4) << '\n';
    int lb = lowerBound(a, 3), ub = upperBound(a, 3);
    cout << "lowerBound(3) = " << lb << ", upperBound(3) = " << ub << ", count = " << ub - lb << '\n';
    cout << "isqrt(99) = " << integerSqrt(99) << ", isqrt(100) = " << integerSqrt(100) << '\n';
    cout << "Search in empty array -> " << binarySearch({}, 7) << '\n';
}
