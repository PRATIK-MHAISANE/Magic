/*
 * ==================================================================
 * ALGORITHM       : Quick Sort (Lomuto partition, middle pivot)
 * DOMAIN          : Sorting and Searching / Divide and Conquer
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Picks a pivot, partitions the array so smaller elements go left and
 *   larger go right, then sorts both sides recursively.
 *
 * WHEN TO USE
 *   Fast in practice and in place. Limitation: worst case O(n^2) (bad
 *   pivots, or many equal keys with this partition) and it is not stable.
 *
 * APPROACH
 *   1. Choose the middle element as pivot and move it to the end
 *      (avoids the sorted-input worst case).
 *   2. Scan left to right; every element smaller than the pivot is
 *      swapped into the 'small' region.
 *   3. Place the pivot right after the small region; it is now in its
 *      final position.
 *   4. Recurse on the left part and the right part.
 *
 * COMPLEXITY
 *   Time : Best/Average O(n log n); Worst O(n^2)
 *   Space: O(log n) average recursion stack; O(n) worst
 *
 * SAMPLE
 *   Input : 10 7 8 9 1 5
 *   Output:
 *     Sorted: 1 5 7 8 9 10
 *     With duplicates: 1 2 3 3 3 3
 *     Empty array: 0 elements
 *
 * COMPILE: g++ -std=c++17 quick_sort.cpp -o quick_sort.exe
 */
#include <bits/stdc++.h>
using namespace std;

int partitionLomuto(vector<int>& a, int lo, int hi) {
    int mid = lo + (hi - lo) / 2;
    swap(a[mid], a[hi]);                    // middle element becomes pivot
    int pivot = a[hi], boundary = lo;
    for (int j = lo; j < hi; j++)
        if (a[j] < pivot) swap(a[boundary++], a[j]);
    swap(a[boundary], a[hi]);
    return boundary;                        // final index of the pivot
}

void quickSortRange(vector<int>& a, int lo, int hi) {
    if (lo >= hi) return;
    int p = partitionLomuto(a, lo, hi);
    quickSortRange(a, lo, p - 1);
    quickSortRange(a, p + 1, hi);
}

void quickSort(vector<int>& a) {
    if (a.size() > 1) quickSortRange(a, 0, (int)a.size() - 1);
}

static void show(const string& label, const vector<int>& a) {
    cout << label << ":";
    for (int x : a) cout << ' ' << x;
    cout << '\n';
}

int main() {
    vector<int> a = {10, 7, 8, 9, 1, 5};
    quickSort(a);
    show("Sorted", a);
    vector<int> d = {3, 3, 3, 1, 2, 3};
    quickSort(d);
    show("With duplicates", d);
    vector<int> empty;
    quickSort(empty);
    cout << "Empty array: " << empty.size() << " elements\n";
}
