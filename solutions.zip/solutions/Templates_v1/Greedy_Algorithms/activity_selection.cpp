/*
 * ==================================================================
 * ALGORITHM       : Activity Selection
 * DOMAIN          : Greedy Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Selects the maximum number of non-overlapping activities from a list
 *   of (start, finish) times.
 *
 * WHEN TO USE
 *   Scheduling rooms/machines with one resource. Greedy works because
 *   finishing early leaves the most room for later activities. Not valid
 *   if activities have different values (that needs DP).
 *
 * APPROACH
 *   1. Sort activities by finish time (ties: earlier start first).
 *   2. Pick the first activity.
 *   3. Walk through the rest; take an activity whenever its start >=
 *      finish of the last chosen one.
 *
 * COMPLEXITY
 *   Time : O(n log n) (sorting dominates)
 *   Space: O(n) for the result
 *
 * SAMPLE
 *   Input : (1,4) (3,5) (0,6) (5,7) (3,9) (5,9) (6,10) (8,11) (8,12)
 *          (2,14) (12,16)
 *   Output:
 *     Selected: (1,4) (5,7) (8,11) (12,16)
 *     Count: 4
 *     Empty input count: 0
 *
 * COMPILE: g++ -std=c++17 activity_selection.cpp -o activity_selection.exe
 */
#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> Activity;          // (start, finish)

vector<Activity> activitySelection(vector<Activity> acts) {
    for (auto& a : acts)
        if (a.first > a.second) throw invalid_argument("start must not exceed finish");
    // Sort by finish time; break ties by start time so that a zero-length
    // activity such as (10,10) is considered after (7,10), not before it.
    sort(acts.begin(), acts.end(), [](const Activity& x, const Activity& y) {
        if (x.second != y.second) return x.second < y.second;
        return x.first < y.first;
    });
    vector<Activity> chosen;
    int lastFinish = INT_MIN;
    for (auto& a : acts)
        if (a.first >= lastFinish) {
            chosen.push_back(a);
            lastFinish = a.second;
        }
    return chosen;
}

int main() {
    auto chosen = activitySelection({{1, 4}, {3, 5}, {0, 6}, {5, 7}, {3, 9}, {5, 9},
                                     {6, 10}, {8, 11}, {8, 12}, {2, 14}, {12, 16}});
    cout << "Selected:";
    for (auto& a : chosen) cout << " (" << a.first << ',' << a.second << ')';
    cout << "\nCount: " << chosen.size() << '\n';
    cout << "Empty input count: " << activitySelection({}).size() << '\n';
}
