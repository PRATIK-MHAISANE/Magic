/*
 * ==================================================================
 * ALGORITHM       : Job Sequencing with Deadlines
 * DOMAIN          : Greedy Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Schedules unit-time jobs, each with a deadline and a profit, to
 *   maximise total profit; each job occupies one time slot.
 *
 * WHEN TO USE
 *   Single-machine scheduling with deadlines. Greedy by profit is optimal
 *   when every job takes exactly one time unit.
 *
 * APPROACH
 *   1. Sort jobs by profit, highest first.
 *   2. For each job, search for a free slot from its deadline
 *      backwards to slot 1.
 *   3. If a free slot exists, place the job there; otherwise skip the
 *      job.
 *   4. Slots are numbered 1..maxDeadline.
 *
 * COMPLEXITY
 *   Time : O(n log n + n * D) where D = max deadline
 *   Space: O(D)
 *
 * SAMPLE
 *   Input : jobs (id, deadline, profit): a 2 100, b 1 19, c 2 27, d 1 25,
 *          e 3 15
 *   Output:
 *     Schedule: c a e
 *     Total profit: 142
 *
 * COMPILE: g++ -std=c++17 job_sequencing.cpp -o job_sequencing.exe
 */
#include <bits/stdc++.h>
using namespace std;

struct Job { char id; int deadline; int profit; };

// Returns the slot array (index 0 = slot 1); '\0' marks an empty slot.
vector<char> jobSequencing(vector<Job> jobs, int& totalProfit) {
    totalProfit = 0;
    if (jobs.empty()) return {};
    int maxDeadline = 0;
    for (auto& j : jobs) {
        if (j.deadline < 1) throw invalid_argument("deadline must be >= 1");
        maxDeadline = max(maxDeadline, j.deadline);
    }
    sort(jobs.begin(), jobs.end(), [](const Job& a, const Job& b) { return a.profit > b.profit; });
    vector<char> slot(maxDeadline, '\0');
    for (auto& j : jobs)
        for (int t = j.deadline - 1; t >= 0; t--)
            if (slot[t] == '\0') {
                slot[t] = j.id;
                totalProfit += j.profit;
                break;
            }
    return slot;
}

int main() {
    int profit;
    auto slots = jobSequencing({{'a', 2, 100}, {'b', 1, 19}, {'c', 2, 27}, {'d', 1, 25}, {'e', 3, 15}}, profit);
    cout << "Schedule:";
    for (char c : slots)
        if (c != '\0') cout << ' ' << c;
    cout << "\nTotal profit: " << profit << '\n';
}
