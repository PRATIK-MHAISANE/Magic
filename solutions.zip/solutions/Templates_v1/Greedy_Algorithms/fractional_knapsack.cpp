/*
 * ==================================================================
 * ALGORITHM       : Fractional Knapsack
 * DOMAIN          : Greedy Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Fills a knapsack of limited capacity to maximise total value when
 *   items can be split into fractions.
 *
 * WHEN TO USE
 *   Resource allocation where goods are divisible. Greedy is optimal
 *   here; for indivisible items (0/1 knapsack) greedy fails and DP is
 *   required.
 *
 * APPROACH
 *   1. Compute value/weight ratio for each item.
 *   2. Sort items by ratio, highest first.
 *   3. Take whole items while they fit; for the first item that does
 *      not fit, take the fraction that fills the remaining capacity.
 *
 * COMPLEXITY
 *   Time : O(n log n)
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : items (value,weight): (60,10) (100,20) (120,30), capacity 50
 *   Output:
 *     Maximum value: 240.00
 *     Fractions taken: 1.00 1.00 0.67
 *
 * COMPILE: g++ -std=c++17 fractional_knapsack.cpp -o fractional_knapsack.exe
 */
#include <bits/stdc++.h>
using namespace std;

struct Item { double value, weight; };

// Returns max value; fractionTaken[i] is the share of item i taken (original order).
double fractionalKnapsack(const vector<Item>& items, double capacity, vector<double>& fractionTaken) {
    if (capacity < 0) throw invalid_argument("capacity must be >= 0");
    for (auto& it : items)
        if (it.weight <= 0 || it.value < 0) throw invalid_argument("weight must be > 0, value >= 0");

    int n = items.size();
    vector<int> idx(n);
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(), [&](int a, int b) {
        return items[a].value / items[a].weight > items[b].value / items[b].weight;
    });

    fractionTaken.assign(n, 0.0);
    double total = 0, remaining = capacity;
    for (int i : idx) {
        if (remaining <= 0) break;
        double take = min(items[i].weight, remaining);
        fractionTaken[i] = take / items[i].weight;
        total += items[i].value * fractionTaken[i];
        remaining -= take;
    }
    return total;
}

int main() {
    vector<double> fractions;
    double best = fractionalKnapsack({{60, 10}, {100, 20}, {120, 30}}, 50, fractions);
    cout << fixed << setprecision(2);
    cout << "Maximum value: " << best << '\n';
    cout << "Fractions taken:";
    for (double f : fractions) cout << ' ' << f;
    cout << '\n';
}
