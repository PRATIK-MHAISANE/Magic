/*
 * ==================================================================
 * ALGORITHM       : Huffman Coding
 * DOMAIN          : Greedy Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Builds an optimal prefix-free binary code: frequent symbols get short
 *   codes, rare symbols get long codes.
 *
 * WHEN TO USE
 *   Lossless data compression. Optimal among prefix codes for known
 *   symbol frequencies.
 *
 * APPROACH
 *   1. Make a leaf node for every symbol with its frequency; put all
 *      in a min-heap.
 *   2. Repeatedly remove the two smallest nodes and merge them into a
 *      new node whose frequency is their sum.
 *   3. The last remaining node is the root of the Huffman tree.
 *   4. Walk the tree: left edge = '0', right edge = '1'; the path to
 *      a leaf is its code.
 *   5. Total encoded bits = sum(frequency x code length).
 *
 * COMPLEXITY
 *   Time : O(n log n)
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : a:5 b:9 c:12 d:13 e:16 f:45
 *   Output:
 *     Code lengths: a:4 b:4 c:3 d:3 e:3 f:1
 *     Total encoded bits: 224
 *     Prefix-free: yes
 *
 * COMPILE: g++ -std=c++17 huffman_coding.cpp -o huffman_coding.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct HuffNode { ll freq; int left, right; };   // children are -1 for leaves

static void assignCodes(const vector<HuffNode>& nodes, const vector<pair<char, ll>>& symbols,
                        int id, string& current, map<char, string>& codes) {
    if (id < (int)symbols.size()) {               // leaf: node id == symbol index
        codes[symbols[id].first] = current.empty() ? "0" : current;
        return;
    }
    current.push_back('0'); assignCodes(nodes, symbols, nodes[id].left, current, codes); current.pop_back();
    current.push_back('1'); assignCodes(nodes, symbols, nodes[id].right, current, codes); current.pop_back();
}

map<char, string> huffmanCodes(const vector<pair<char, ll>>& symbols) {
    map<char, string> codes;
    if (symbols.empty()) return codes;
    vector<HuffNode> nodes;
    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<>> pq;   // (freq, node id)
    for (size_t i = 0; i < symbols.size(); i++) {
        if (symbols[i].second <= 0) throw invalid_argument("frequency must be positive");
        nodes.push_back({symbols[i].second, -1, -1});
        pq.push({symbols[i].second, (int)i});
    }
    while (pq.size() > 1) {
        auto a = pq.top(); pq.pop();
        auto b = pq.top(); pq.pop();
        nodes.push_back({a.first + b.first, a.second, b.second});
        pq.push({a.first + b.first, (int)nodes.size() - 1});
    }
    string current;
    assignCodes(nodes, symbols, pq.top().second, current, codes);
    return codes;
}

int main() {
    vector<pair<char, ll>> symbols = {{'a', 5}, {'b', 9}, {'c', 12}, {'d', 13}, {'e', 16}, {'f', 45}};
    auto codes = huffmanCodes(symbols);

    cout << "Code lengths:";
    ll totalBits = 0;
    for (auto& [sym, freq] : symbols) {
        cout << ' ' << sym << ':' << codes[sym].size();
        totalBits += freq * (ll)codes[sym].size();
    }
    cout << "\nTotal encoded bits: " << totalBits << '\n';

    bool prefixFree = true;                        // no code may be a prefix of another
    for (auto& [s1, c1] : codes)
        for (auto& [s2, c2] : codes)
            if (s1 != s2 && c2.compare(0, c1.size(), c1) == 0) prefixFree = false;
    cout << "Prefix-free: " << (prefixFree ? "yes" : "no") << '\n';
}
