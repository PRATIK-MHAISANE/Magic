/*
 * ==================================================================
 * ALGORITHM       : Knuth-Morris-Pratt (KMP) Pattern Matching
 * DOMAIN          : String Algorithms
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Finds every occurrence of a pattern in a text in linear time by never
 *   re-examining text characters, using a precomputed failure table
 *   (LPS).
 *
 * WHEN TO USE
 *   Substring search when the naive O(n*m) scan is too slow, or when the
 *   text has many repeated prefixes.
 *
 * APPROACH
 *   1. LPS[i] = length of the longest proper prefix of pat[0..i] that
 *      is also a suffix of it.
 *   2. Scan the text; keep k = number of pattern characters currently
 *      matched.
 *   3. On a mismatch, fall back k = LPS[k-1] instead of restarting;
 *      the text pointer never moves backwards.
 *   4. When k == m, record a match at i-m+1 and continue with k =
 *      LPS[k-1] (overlapping matches are found).
 *
 * COMPLEXITY
 *   Time : O(n + m)
 *   Space: O(m)
 *
 * SAMPLE
 *   Input : text = ababcabab, pattern = abab;  text = aaaa, pattern = aa
 *   Output:
 *     LPS of abab: 0 0 1 2
 *     Matches of "abab" in "ababcabab": 0 5
 *     Matches of "aa" in "aaaa": 0 1 2
 *     Empty pattern: rejected
 *
 * COMPILE: g++ -std=c++17 kmp.cpp -o kmp.exe
 */
#include <bits/stdc++.h>
using namespace std;

vector<int> buildLPS(const string& pat) {
    vector<int> lps(pat.size(), 0);
    for (size_t i = 1, k = 0; i < pat.size(); i++) {
        while (k > 0 && pat[i] != pat[k]) k = lps[k - 1];
        if (pat[i] == pat[k]) k++;
        lps[i] = k;
    }
    return lps;
}

// Start index of every occurrence (overlaps included).
vector<int> kmpSearch(const string& text, const string& pat) {
    if (pat.empty()) throw invalid_argument("pattern must not be empty");
    vector<int> lps = buildLPS(pat), matches;
    size_t k = 0;
    for (size_t i = 0; i < text.size(); i++) {
        while (k > 0 && text[i] != pat[k]) k = lps[k - 1];
        if (text[i] == pat[k]) k++;
        if (k == pat.size()) {
            matches.push_back((int)(i + 1 - pat.size()));
            k = lps[k - 1];
        }
    }
    return matches;
}

int main() {
    cout << "LPS of abab:";
    for (int v : buildLPS("abab")) cout << ' ' << v;
    cout << '\n';
    cout << "Matches of \"abab\" in \"ababcabab\":";
    for (int p : kmpSearch("ababcabab", "abab")) cout << ' ' << p;
    cout << "\nMatches of \"aa\" in \"aaaa\":";
    for (int p : kmpSearch("aaaa", "aa")) cout << ' ' << p;
    cout << '\n';
    bool rejected = false;
    try { kmpSearch("abc", ""); } catch (const invalid_argument&) { rejected = true; }
    cout << "Empty pattern: " << (rejected ? "rejected" : "accepted") << '\n';
}
