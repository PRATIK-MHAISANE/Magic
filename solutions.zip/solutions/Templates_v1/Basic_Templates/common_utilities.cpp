/*
 * ==================================================================
 * ALGORITHM       : Common Number Utilities (gcd, lcm, modPow, isPrime, sieve)
 * DOMAIN          : Basic Templates
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Small number-theory helpers that appear inside many other programs.
 *
 * WHEN TO USE
 *   gcd/lcm for fractions and periods, modPow for large powers under a
 *   modulus, isPrime for one number, sieve for all primes up to n.
 *
 * APPROACH
 *   1. gcd: Euclid's algorithm, repeat (a, b) -> (b, a mod b) until b
 *      is 0.
 *   2. lcm = |a / gcd * b| (divide first to avoid overflow).
 *   3. modPow: square-and-multiply on the bits of the exponent.
 *   4. isPrime: trial division up to sqrt(n).
 *   5. sieve: for each prime p, mark p*p, p*p+p, ... as composite.
 *
 * COMPLEXITY
 *   Time : gcd O(log min(a,b)); modPow O(log exp); isPrime O(sqrt n);
 *          sieve O(n log log n)
 *   Space: O(1) for gcd/lcm/modPow/isPrime; O(n) for sieve
 *
 * SAMPLE
 *   Input : (no input, fixed demo values)
 *   Output:
 *     gcd(12,18) = 6
 *     lcm(4,6) = 12
 *     2^10 mod 1e9+7 = 1024
 *     isPrime(97) = 1
 *     Primes up to 20: 2 3 5 7 11 13 17 19
 *
 * COMPILE: g++ -std=c++17 common_utilities.cpp -o common_utilities.exe
 */
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll gcdLL(ll a, ll b) {
    while (b != 0) { a %= b; swap(a, b); }
    return a < 0 ? -a : a;
}

ll lcmLL(ll a, ll b) {
    if (a == 0 || b == 0) return 0;
    ll result = a / gcdLL(a, b) * b;
    return result < 0 ? -result : result;
}

// (base^exp) % mod, requires exp >= 0 and mod > 0
ll modPow(ll base, ll exp, ll mod) {
    if (exp < 0 || mod <= 0) throw invalid_argument("exp must be >= 0 and mod > 0");
    ll result = 1 % mod;
    base %= mod;
    if (base < 0) base += mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}

bool isPrime(ll n) {
    if (n < 2) return false;
    for (ll i = 2; i * i <= n; i++)
        if (n % i == 0) return false;
    return true;
}

// Returns all primes <= n (Sieve of Eratosthenes)
vector<int> sieve(int n) {
    vector<int> primes;
    if (n < 2) return primes;
    vector<bool> composite(n + 1, false);
    for (ll i = 2; i <= n; i++) {
        if (composite[i]) continue;
        primes.push_back((int)i);
        for (ll j = i * i; j <= n; j += i) composite[j] = true;
    }
    return primes;
}

int main() {
    cout << "gcd(12,18) = " << gcdLL(12, 18) << '\n';
    cout << "lcm(4,6) = " << lcmLL(4, 6) << '\n';
    cout << "2^10 mod 1e9+7 = " << modPow(2, 10, 1000000007) << '\n';
    cout << "isPrime(97) = " << isPrime(97) << '\n';
    cout << "Primes up to 20:";
    for (int p : sieve(20)) cout << ' ' << p;
    cout << '\n';
}
