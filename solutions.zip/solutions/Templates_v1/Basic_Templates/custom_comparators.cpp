/*
 * ==================================================================
 * ALGORITHM       : Custom Comparators
 * DOMAIN          : Basic Templates
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Shows the three common ways to define a custom ordering: a comparison
 *   function, a functor, and a functor for priority_queue.
 *
 * WHEN TO USE
 *   Whenever sort() or a heap must use a rule other than the default (for
 *   example by second field, or by length then alphabetically).
 *
 * APPROACH
 *   1. A comparator returns true if the first argument must come
 *      BEFORE the second.
 *   2. It must be a strict weak ordering (use < or >, never <= or
 *      >=).
 *   3. priority_queue is a max-heap, so its comparator is reversed:
 *      to get the smallest first, return a > b.
 *
 * COMPLEXITY
 *   Time : sort with comparator: O(n log n) comparisons
 *   Space: O(1) extra for the comparators
 *
 * SAMPLE
 *   Input : (no input, fixed demo values)
 *   Output:
 *     Pairs: (1,5) (3,5) (2,3) (4,1)
 *     Strings: fig kiwi pear apple
 *     Tasks: a b c
 *
 * COMPILE: g++ -std=c++17 custom_comparators.cpp -o custom_comparators.exe
 */
#include <bits/stdc++.h>
using namespace std;

// 1) Function: by second DESC, ties by first ASC
bool bySecondDescThenFirstAsc(const pair<int, int>& a, const pair<int, int>& b) {
    if (a.second != b.second) return a.second > b.second;
    return a.first < b.first;
}

// 2) Functor: by length, ties alphabetical
struct ByLengthThenAlpha {
    bool operator()(const string& a, const string& b) const {
        if (a.size() != b.size()) return a.size() < b.size();
        return a < b;
    }
};

// 3) priority_queue comparator: smallest priority comes out first (min-heap)
struct Task {
    int priority;
    string name;
};
struct TaskLater {
    bool operator()(const Task& a, const Task& b) const { return a.priority > b.priority; }
};

int main() {
    vector<pair<int, int>> pairs = {{1, 5}, {2, 3}, {3, 5}, {4, 1}};
    sort(pairs.begin(), pairs.end(), bySecondDescThenFirstAsc);
    cout << "Pairs:";
    for (auto& p : pairs) cout << " (" << p.first << ',' << p.second << ')';
    cout << '\n';

    vector<string> words = {"pear", "fig", "apple", "kiwi"};
    sort(words.begin(), words.end(), ByLengthThenAlpha());
    cout << "Strings:";
    for (auto& w : words) cout << ' ' << w;
    cout << '\n';

    priority_queue<Task, vector<Task>, TaskLater> pq;
    pq.push({3, "c"}); pq.push({1, "a"}); pq.push({2, "b"});
    cout << "Tasks:";
    while (!pq.empty()) { cout << ' ' << pq.top().name; pq.pop(); }
    cout << '\n';
}
