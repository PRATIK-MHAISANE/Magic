/*
 * ==================================================================
 * ALGORITHM       : Disjoint Set Union (Union-Find)
 * DOMAIN          : Basic Templates / Data Structures
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Maintains a partition of elements into groups and supports 'which
 *   group?' and 'merge two groups' in almost constant time.
 *
 * WHEN TO USE
 *   Kruskal's MST, connected components, cycle detection in undirected
 *   graphs. Limitation: it cannot split a group once merged.
 *
 * APPROACH
 *   1. Each element points to a parent; a root points to itself.
 *   2. find(x): follow parents to the root, compressing the path as
 *      we go.
 *   3. unite(a, b): attach the smaller tree under the larger one
 *      (union by size).
 *   4. If both roots are equal, a and b are already in the same
 *      group.
 *
 * COMPLEXITY
 *   Time : O(alpha(n)) amortised per operation (practically constant)
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : n = 6; unite(0,1), unite(1,2), unite(3,4)
 *   Output:
 *     Components: 3
 *     connected(0,2): 1
 *     connected(0,3): 0
 *     Size of set of 0: 3
 *     unite(0,2) again: 0
 *
 * COMPILE: g++ -std=c++17 disjoint_set_union.cpp -o disjoint_set_union.exe
 */
#include <bits/stdc++.h>
using namespace std;

class DisjointSet {
    vector<int> parent, setSize;
    int componentCount;

public:
    explicit DisjointSet(int n) : parent(n), setSize(n, 1), componentCount(n) {
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {                       // path halving
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        return x;
    }
    bool unite(int a, int b) {              // false if already together
        a = find(a); b = find(b);
        if (a == b) return false;
        if (setSize[a] < setSize[b]) swap(a, b);
        parent[b] = a;
        setSize[a] += setSize[b];
        componentCount--;
        return true;
    }
    bool connected(int a, int b) { return find(a) == find(b); }
    int components() const { return componentCount; }
    int sizeOf(int x) { return setSize[find(x)]; }
};

int main() {
    DisjointSet dsu(6);
    dsu.unite(0, 1); dsu.unite(1, 2); dsu.unite(3, 4);
    cout << "Components: " << dsu.components() << '\n';
    cout << "connected(0,2): " << dsu.connected(0, 2) << '\n';
    cout << "connected(0,3): " << dsu.connected(0, 3) << '\n';
    cout << "Size of set of 0: " << dsu.sizeOf(0) << '\n';
    cout << "unite(0,2) again: " << dsu.unite(0, 2) << '\n';
}
