/*
 * ==================================================================
 * ALGORITHM       : Fast Input/Output
 * DOMAIN          : Basic Templates
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Turns off C++ stream synchronisation with C stdio so cin/cout become
 *   much faster. Includes a safe routine that reads n followed by n
 *   integers.
 *
 * WHEN TO USE
 *   Use when a program reads or prints many values (10^5 or more).
 *   Limitation: after enabling it, do not mix cin/cout with scanf/printf.
 *
 * APPROACH
 *   1. Call ios::sync_with_stdio(false) and cin.tie(nullptr) once at
 *      the start of main().
 *   2. Print '\n' instead of endl (endl flushes the buffer every
 *      time).
 *   3. Check every read for failure so bad input is handled.
 *
 * COMPLEXITY
 *   Time : O(n) to read n values
 *   Space: O(n) to store them
 *
 * SAMPLE
 *   Input : 5 1 2 3 4 5
 *   Output:
 *     Sum = 15
 *
 * COMPILE: g++ -std=c++17 fast_io.cpp -o fast_io.exe
 */
#include <bits/stdc++.h>
using namespace std;

// Call once at the start of main(). Do not mix with scanf/printf afterwards.
void enableFastIO() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
}

// Reads n followed by n integers. Returns false on malformed input.
bool readArray(vector<long long>& a) {
    int n;
    if (!(cin >> n) || n < 0) return false;
    a.assign(n, 0);
    for (auto& x : a)
        if (!(cin >> x)) return false;
    return true;
}

int main() {
    enableFastIO();
    vector<long long> a;
    if (!readArray(a)) {
        cout << "Invalid input\n";
        return 0;
    }
    cout << "Sum = " << accumulate(a.begin(), a.end(), 0LL) << '\n';
}
