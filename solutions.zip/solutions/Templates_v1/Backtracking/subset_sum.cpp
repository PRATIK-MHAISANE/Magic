/*
 * ==================================================================
 * ALGORITHM       : Subset Sum (backtracking)
 * DOMAIN          : Backtracking
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Decides whether some subset of positive integers adds up to a target;
 *   finds one such subset and counts all of them.
 *
 * WHEN TO USE
 *   Include/exclude decision trees. Pruning (skip an element that exceeds
 *   the remaining target) cuts the search. For large targets with
 *   moderate n, DP is faster.
 *
 * APPROACH
 *   1. At each index decide: include the element (if it fits) or
 *      exclude it.
 *   2. Include: reduce the remaining target and recurse; if that
 *      fails, remove it (backtrack).
 *   3. Stop successfully when the remaining target reaches 0.
 *   4. Counting version explores both branches fully and sums the
 *      results.
 *
 * COMPLEXITY
 *   Time : O(2^n) worst case
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : {3, 34, 4, 12, 5, 2}, target 9;  also target 100
 *   Output:
 *     One subset summing to 9: 3 4 2
 *     Number of subsets: 2
 *     Target 100: none
 *
 * COMPILE: g++ -std=c++17 subset_sum.cpp -o subset_sum.exe
 */
#include <bits/stdc++.h>
using namespace std;

static bool findSubset(const vector<int>& a, size_t idx, int remaining, vector<int>& current) {
    if (remaining == 0) return true;
    if (idx == a.size()) return false;
    if (a[idx] <= remaining) {                       // option 1: include
        current.push_back(a[idx]);
        if (findSubset(a, idx + 1, remaining - a[idx], current)) return true;
        current.pop_back();                          // backtrack
    }
    return findSubset(a, idx + 1, remaining, current);   // option 2: exclude
}

static long long countSubsets(const vector<int>& a, size_t idx, int remaining) {
    if (remaining == 0) return 1;                    // all values are positive, so stop here
    if (idx == a.size()) return 0;
    long long ways = countSubsets(a, idx + 1, remaining);
    if (a[idx] <= remaining) ways += countSubsets(a, idx + 1, remaining - a[idx]);
    return ways;
}

static void validate(const vector<int>& a, int target) {
    if (target < 0) throw invalid_argument("target must be >= 0");
    for (int x : a) if (x <= 0) throw invalid_argument("elements must be positive");
}

// Returns true and fills 'subset' if a subset with the given sum exists.
bool subsetSum(const vector<int>& a, int target, vector<int>& subset) {
    validate(a, target);
    subset.clear();
    return findSubset(a, 0, target, subset);
}

long long countSubsetSum(const vector<int>& a, int target) {
    validate(a, target);
    return countSubsets(a, 0, target);
}

int main() {
    vector<int> a = {3, 34, 4, 12, 5, 2};
    vector<int> subset;
    if (subsetSum(a, 9, subset)) {
        cout << "One subset summing to 9:";
        for (int x : subset) cout << ' ' << x;
        cout << '\n';
    }
    cout << "Number of subsets: " << countSubsetSum(a, 9) << '\n';
    cout << "Target 100: " << (subsetSum(a, 100, subset) ? "found" : "none") << '\n';
}
