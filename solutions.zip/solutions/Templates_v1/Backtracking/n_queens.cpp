/*
 * ==================================================================
 * ALGORITHM       : N-Queens
 * DOMAIN          : Backtracking
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Places N queens on an N x N board so that no two attack each other
 *   (no shared row, column or diagonal). Counts solutions and prints the
 *   first.
 *
 * WHEN TO USE
 *   Standard example of backtracking: build a solution step by step and
 *   undo (backtrack) when a partial solution cannot be completed.
 *
 * APPROACH
 *   1. Place one queen per row, trying each column from left to
 *      right.
 *   2. Keep three boolean arrays: used columns, used '/' diagonals
 *      (row+col), used '\' diagonals (row-col+n-1).
 *   3. If a column is safe: mark it, recurse to the next row, then
 *      UNMARK it (backtrack).
 *   4. When row == n, a full valid placement exists.
 *
 * COMPLEXITY
 *   Time : O(n!) worst case (heavily pruned in practice)
 *   Space: O(n)
 *
 * SAMPLE
 *   Input : n = 1..8; print first solution for n = 4
 *   Output:
 *     Solutions: n=1:1 n=2:0 n=3:0 n=4:2 n=5:10 n=6:4 n=7:40 n=8:92
 *     First solution for n=4:
 *     .Q..
 *     ...Q
 *     Q...
 *     ..Q.
 *
 * COMPILE: g++ -std=c++17 n_queens.cpp -o n_queens.exe
 */
#include <bits/stdc++.h>
using namespace std;

class NQueens {
    int n;
    vector<bool> colUsed, diag1, diag2;
    vector<int> placement;            // placement[row] = column
    vector<int> firstSolution;
    long long solutions = 0;

    void solve(int row) {
        if (row == n) {
            if (solutions == 0) firstSolution = placement;
            solutions++;
            return;
        }
        for (int col = 0; col < n; col++) {
            if (colUsed[col] || diag1[row + col] || diag2[row - col + n - 1]) continue;
            colUsed[col] = diag1[row + col] = diag2[row - col + n - 1] = true;   // choose
            placement[row] = col;
            solve(row + 1);
            colUsed[col] = diag1[row + col] = diag2[row - col + n - 1] = false;  // un-choose
        }
    }

public:
    explicit NQueens(int size) : n(size) {
        if (n < 1) throw invalid_argument("n must be >= 1");
        colUsed.assign(n, false);
        diag1.assign(2 * n, false);
        diag2.assign(2 * n, false);
        placement.assign(n, -1);
    }
    long long countSolutions() { solutions = 0; solve(0); return solutions; }
    vector<string> firstBoard() const {
        vector<string> board;
        for (int row = 0; row < (int)firstSolution.size(); row++) {
            string line(n, '.');
            line[firstSolution[row]] = 'Q';
            board.push_back(line);
        }
        return board;
    }
};

int main() {
    cout << "Solutions:";
    for (int n = 1; n <= 8; n++) cout << " n=" << n << ':' << NQueens(n).countSolutions();
    cout << '\n';
    NQueens q(4);
    q.countSolutions();
    cout << "First solution for n=4:\n";
    for (auto& line : q.firstBoard()) cout << line << '\n';
}
