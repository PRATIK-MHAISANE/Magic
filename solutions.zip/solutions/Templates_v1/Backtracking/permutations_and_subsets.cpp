/*
 * ==================================================================
 * ALGORITHM       : Generate Permutations and Subsets
 * DOMAIN          : Backtracking
 * CA LAB REF      : (fill in assignment/question number)
 * CLASSIFICATION  : (confirm: Assignment-Based / Syllabus-Based / Additional)
 * ==================================================================
 *
 * DESCRIPTION
 *   Systematically generates every permutation and every subset (power
 *   set) of a list using choose / explore / un-choose.
 *
 * WHEN TO USE
 *   Brute-force enumeration for small n, and the base pattern behind most
 *   backtracking problems.
 *
 * APPROACH
 *   1. Permutations: keep a 'used' flag per element; at each position
 *      try every unused element, recurse, then unmark it. This yields
 *      lexicographic order for sorted input.
 *   2. Subsets: record the current list at every node; then for each
 *      later element add it, recurse, remove it.
 *   3. Brute force would try all candidates blindly; backtracking
 *      abandons a branch as soon as it cannot lead to a valid answer.
 *
 * COMPLEXITY
 *   Time : Permutations O(n * n!); Subsets O(n * 2^n)
 *   Space: O(n) recursion (excluding output)
 *
 * SAMPLE
 *   Input : {1, 2, 3}
 *   Output:
 *     Permutations of {1,2,3}:
 *     1 2 3
 *     1 3 2
 *     2 1 3
 *     2 3 1
 *     3 1 2
 *     3 2 1
 *     Subsets of {1,2,3}:
 *     {}
 *     {1}
 *     {1 2}
 *     {1 2 3}
 *     {1 3}
 *     {2}
 *     {2 3}
 *     {3}
 *
 * COMPILE: g++ -std=c++17 permutations_and_subsets.cpp -o permutations_and_subsets.exe
 */
#include <bits/stdc++.h>
using namespace std;

static void permute(const vector<int>& a, vector<bool>& used, vector<int>& current,
                    vector<vector<int>>& result) {
    if (current.size() == a.size()) { result.push_back(current); return; }
    for (size_t i = 0; i < a.size(); i++) {
        if (used[i]) continue;
        used[i] = true; current.push_back(a[i]);        // choose
        permute(a, used, current, result);              // explore
        current.pop_back(); used[i] = false;            // un-choose
    }
}

vector<vector<int>> allPermutations(const vector<int>& a) {
    vector<vector<int>> result;
    vector<bool> used(a.size(), false);
    vector<int> current;
    permute(a, used, current, result);
    return result;
}

static void subsetsFrom(const vector<int>& a, size_t start, vector<int>& current,
                        vector<vector<int>>& result) {
    result.push_back(current);                          // every node is a subset
    for (size_t i = start; i < a.size(); i++) {
        current.push_back(a[i]);
        subsetsFrom(a, i + 1, current, result);
        current.pop_back();
    }
}

vector<vector<int>> allSubsets(const vector<int>& a) {
    vector<vector<int>> result;
    vector<int> current;
    subsetsFrom(a, 0, current, result);
    return result;
}

int main() {
    vector<int> a = {1, 2, 3};
    cout << "Permutations of {1,2,3}:\n";
    for (auto& p : allPermutations(a)) {
        for (size_t i = 0; i < p.size(); i++) cout << (i ? " " : "") << p[i];
        cout << '\n';
    }
    cout << "Subsets of {1,2,3}:\n";
    for (auto& s : allSubsets(a)) {
        cout << '{';
        for (size_t i = 0; i < s.size(); i++) cout << (i ? " " : "") << s[i];
        cout << "}\n";
    }
}
