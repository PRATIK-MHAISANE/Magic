// Problem: Graph Coloring Backtracking
// Original file: A10_Q02.cpp

/* Problem Statement:
Graph Coloring Backtracking

Approach:
Use backtracking to assign colors to graph vertices.
*/

#include <iostream>
using namespace std;
int n, graph[20][20], color[20];
bool isSafe(int vertex, int c) {
    for (int i = 0; i < n; i++) {
        if (graph[vertex][i] == 1 && color[i] == c)
            return false;
    }
    return true;
}
bool solve(int vertex, int m) {
    if (vertex == n)
        return true;
    for (int c = 1; c <= m; c++) {
        if (isSafe(vertex, c)) {
            color[vertex] = c;
            if (solve(vertex + 1, m))
                return true;
            color[vertex] = 0;
        }
    }
    return false;
}
int main() {
    cout << "Enter number of vertices: ";
    cin >> n;
    if (n < 1 || n > 20) {
        cout << "Invalid number of vertices\n";
        return 0;
    }
    
cout << "Enter adjacency matrix:\n";
for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
        cin >> graph[i][j];
    }
}
// Check for self-loops
for (int i = 0; i < n; i++) {
    if (graph[i][i] == 1) {
        cout << "No coloring possible: Self-loop detected\n";
        return 0;
    }
}
    for (int m = 1; m <= n; m++) {
        for (int i = 0; i < n; i++)
            color[i] = 0;
        if (solve(0, m)) {
            cout << "Minimum colors: " << m << endl;
            cout << "Color assignment: ";
            for (int i = 0; i < n; i++)
                cout << "V" << i + 1 << "="
                     << color[i] << " ";
            cout << endl;
            return 0;
        }
    }
    cout << "No coloring possible\n";
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra graph_coloring_backtracking.cpp -o graph_coloring_backtracking.exe && .\graph_coloring_backtracking.exe
