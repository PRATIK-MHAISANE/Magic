// Problem: Merge Sorted Array B into Array A
// Assignment: 1
// Question: 1
// Domain: 06_Sorting_Searching

/* Problem Statement:
You are given two sorted arrays, A and B, where A has a large enough buffer at the end to hold B. Write a method to merge B into A in sorted order.

Approach:
Merge starting from the back: compare the last valid elements of A and B, place the larger one at the last empty slot, and move backward. This avoids shifting.
*/

#include <bits/stdc++.h>
using namespace std;
void mergeSorted(vector<int>& A, int m, vector<int>& B, int n) {
    int i = m - 1;
    int j = n - 1;
    int k = m + n - 1;
    while (j >= 0) {
        if (i >= 0 && A[i] > B[j]) A[k--] = A[i--];
        else A[k--] = B[j--];
    }
}
int main() {
    vector<int> A = {1, 3, 5, 0, 0, 0};
    vector<int> B = {2, 4, 6};
    mergeSorted(A, 3, B, 3);
    for (int x : A) cout << x << " ";
}

/* Sample Input & Output:
Output: 1 2 3 4 5 6
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q01_Merge_Sorted_Arrays.cpp -o A01_Q01_Merge_Sorted_Arrays.exe && .\A01_Q01_Merge_Sorted_Arrays.exe
