// Problem: Longest Common Subsequence
// Original file: A06_Q04.cpp

/* Problem Statement:
Longest Common Subsequence

Approach:
Use DP table where dp[i][j] stores LCS length.
*/

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
int main() {
    string A, B;
    cout << "Enter first sequence: ";
    cin >> A;
    cout << "Enter second sequence: ";
    cin >> B;
    int m = A.length();
    int n = B.length();
    // DP table
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
    // Build the DP table
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (A[i - 1] == B[j - 1]) {
                // Characters match
                dp[i][j] = dp[i - 1][j - 1] + 1;
            }
            else {
                // Characters don't match
                dp[i][j] = max(dp[i - 1][j],
                               dp[i][j - 1]);
            }
        }
    }
    // Reconstruct LCS
    string lcs = "";
    int i = m;
    int j = n;
    while (i > 0 && j > 0) {
        if (A[i - 1] == B[j - 1]) {
            // This character belongs to LCS
            lcs += A[i - 1];
            i--;
            j--;
        }
        else if (dp[i - 1][j] > dp[i][j - 1]) {
            // Move up
            i--;
        }
        else {
            // Move left
            j--;
        }
    }
    // We constructed it backwards
    reverse(lcs.begin(), lcs.end());
    cout << "Length of LCS: " << dp[m][n] << endl;
    cout << "LCS: " << lcs << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra longest_common_subsequence_v2.cpp -o longest_common_subsequence_v2.exe && .\longest_common_subsequence_v2.exe
