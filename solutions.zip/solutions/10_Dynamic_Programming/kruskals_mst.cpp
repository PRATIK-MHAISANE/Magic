// Problem: Kruskal's MST (DSU)
// Original file: A07_Q16.cpp

/* Problem Statement:
Kruskal's MST (DSU)

Approach:
Sort edges and use Disjoint Set Union to build MST.
*/

#include <algorithm>
using namespace std;
struct Edge
{
    int u, v, cost;
};
class DSU
{
    vector<int> parent, rankValue;
public:
    DSU(int n)
    {
        parent.resize(n);
        rankValue.resize(n, 0);
        for (int i = 0; i < n; i++)
            parent[i] = i;
    }
    int find(int x)
    {
        if (parent[x] != x)
            parent[x] = find(parent[x]);
        return parent[x];
    }
    bool unite(int a, int b)
    {
        a = find(a);
        b = find(b);
        if (a == b)
            return false;
        if (rankValue[a] < rankValue[b])
            swap(a, b);
        parent[b] = a;
        if (rankValue[a] == rankValue[b])
            rankValue[a]++;
        return true;
    }
};
int main()
{
    int n, m;
    cin >> n >> m;
    vector<Edge> edges(m);
    for (int i = 0; i < m; i++)
    {
        cin >> edges[i].u >> edges[i].v >> edges[i].cost;
    }
    sort(edges.begin(), edges.end(),
         [](Edge a, Edge b)
         {
             return a.cost < b.cost;
         });
    DSU dsu(n);
    vector<Edge> mst;
    int totalCost = 0;
    for (Edge e : edges)
    {
        if (dsu.unite(e.u, e.v))
        {
            mst.push_back(e);
            totalCost += e.cost;
            if (mst.size() == n - 1)
                break;
        }
    }
    if (mst.size() == n - 1)
    {
        cout << "MST exists\n";
        cout << "Total minimum cost = " << totalCost << endl;
        cout << "Selected edges:\n";
        for (Edge e : mst)
        {
            cout << e.u << " - " << e.v
                 << " : " << e.cost << endl;
        }
    }
    else
    {
        cout << "Graph is disconnected\n";
        cout << "No complete MST exists\n";
        cout << "Selected edges:\n";
        for (Edge e : mst)
        {
            cout << e.u << " - " << e.v
                 << " : " << e.cost << endl;
        }
        vector<vector<int>> components(n);
        for (int i = 0; i < n; i++)
        {
            components[dsu.find(i)].push_back(i);
        }
        cout << "Disconnected components:\n";
        for (int i = 0; i < n; i++)
        {
            if (!components[i].empty())
            {
                cout << "{ ";
                for (int city : components[i])
                    cout << city << " ";
                cout << "}\n";
            }
        }
    }
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra kruskals_mst.cpp -o kruskals_mst.exe && .\kruskals_mst.exe
