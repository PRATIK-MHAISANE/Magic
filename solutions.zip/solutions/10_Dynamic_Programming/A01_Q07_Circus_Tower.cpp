// Problem: Circus Tower (Longest Increasing Subsequence Variant)
// Assignment: 1
// Question: 7
// Domain: 10_Dynamic_Programming

/* Problem Statement:
Compute the largest possible number of people in a tower. Each person must be both shorter and lighter than the person below them.

Approach:
Sort by height ascending (break ties by weight descending). Then find the Longest Increasing Subsequence (LIS) of the weight values.
*/

#include <bits/stdc++.h>
using namespace std;
int longestTower(vector<pair<int,int>> people) {
    sort(people.begin(), people.end(), [](auto& a, auto& b) {
        if (a.first != b.first) return a.first < b.first;
        return a.second > b.second;
    });
    int n = people.size();
    vector<int> dp(n, 1);
    int best = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            if (people[j].second < people[i].second)
                dp[i] = max(dp[i], dp[j] + 1);
        }
        best = max(best, dp[i]);
    }
    return best;
}
int main() {
    vector<pair<int,int>> people = {
        {65,100}, {70,150}, {56,90}, {75,190}, {60,95}, {68,110}
    };
    cout << longestTower(people);
}

/* Sample Input & Output:
Output: 6
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q07_Circus_Tower.cpp -o A01_Q07_Circus_Tower.exe && .\A01_Q07_Circus_Tower.exe
