// Problem: Frog on the Grid
// Assignment: 2
// Question: 4
// Domain: 17_Mathematics_Number_Theory

/* Problem Statement:
Count the integer points that could be the frog's position after exactly T seconds lying inside a specific square.

Approach:
Clip the square bounds and compute the area overlap mathematically using arithmetic-series sums.
*/

#include <iostream>
#include <algorithm>
using namespace std;
typedef long long LL;
int main() {
    LL T, xl, yl, xr, yr;
    cin >> T >> xl >> yl >> xr >> yr;
    LL total = 0;
    LL hi1 = min(xr, T);
    if (xl <= hi1) {
        total += (hi1 - xl + 1) * (yr - yl + 1);
    }
    LL a = max(xl, T + 1);
    LL b = min(xr, T + yr);
    if (a <= b) {
        LL cnt = b - a + 1;
        total += cnt * (T - yl + 1) - (a + b) * cnt / 2;
    }
    cout << total << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 1 1 2 5
Output: 8
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q04_Frog_On_Grid.cpp -o A02_Q04_Frog_On_Grid.exe && .\A02_Q04_Frog_On_Grid.exe
