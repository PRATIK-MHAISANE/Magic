// Problem: Search in a Matrix with Sorted Rows
// Assignment: 2
// Question: 7
// Domain: 09_Binary_Search

/* Problem Statement:
Determine whether a target value exists in a matrix where every row is independently sorted.

Approach:
Prune rows using O(1) checks (first and last elements), then binary search passing rows.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int M, N, target;
    cin >> M >> N;
    vector<vector<int>> a(M, vector<int>(N));
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) cin >> a[i][j];
    cin >> target;
    int rowsSearched = 0;
    bool found = false;
    int fr = -1, fc = -1;
    for (int i = 0; i < M && !found; i++) {
        if (target < a[i][0] || target > a[i][N - 1]) continue;
        rowsSearched++;
        int lo = 0, hi = N - 1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            if (a[i][mid] == target) { found = true; fr = i; fc = mid; break; }
            if (a[i][mid] < target) lo = mid + 1;
            else hi = mid - 1;
        }
    }
    cout << (found ? "true" : "false") << '\n';
    if (found) cout << "Found at row " << fr << ", column " << fc << " (0-indexed)\n";
    cout << "Rows binary-searched: " << rowsSearched << " of " << M << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 3 3
1 4 7
2 5 8
3 6 9
5
Output: true
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q07_Search_Matrix_Sorted_Rows.cpp -o A02_Q07_Search_Matrix_Sorted_Rows.exe && .\A02_Q07_Search_Matrix_Sorted_Rows.exe
