// Problem: Median of Two Sorted Arrays
// Assignment: 2
// Question: 6
// Domain: 09_Binary_Search

/* Problem Statement:
Given two sorted arrays A and B, find the median of the combined sorted array without merging them.

Approach:
Binary search on the smaller array for the partition element to ensure equal elements on left/right.
*/

#include <bits/stdc++.h>
using namespace std;
double findMedian(vector<int>& A, vector<int>& B) {
    if (A.size() > B.size()) return findMedian(B, A);
    int m = A.size(), n = B.size();
    int lo = 0, hi = m;
    const int NEG = INT_MIN, POS = INT_MAX;
    while (lo <= hi) {
        int i = (lo + hi) / 2;
        int j = (m + n + 1) / 2 - i;
        int Aleft  = (i == 0) ? NEG : A[i - 1];
        int Aright = (i == m) ? POS : A[i];
        int Bleft  = (j == 0) ? NEG : B[j - 1];
        int Bright = (j == n) ? POS : B[j];
        if (Aleft <= Bright && Bleft <= Aright) {
            if ((m + n) % 2 == 1) return max(Aleft, Bleft);
            return (max(Aleft, Bleft) + (double)min(Aright, Bright)) / 2.0;
        }
        if (Aleft > Bright) hi = i - 1;
        else lo = i + 1;
    }
    return 0.0;
}
int main() {
    int m, n;
    cin >> m;
    vector<int> A(m);
    for (int i = 0; i < m; i++) cin >> A[i];
    cin >> n;
    vector<int> B(n);
    for (int i = 0; i < n; i++) cin >> B[i];
    double med = findMedian(A, B);
    cout << "Median = " << med << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 2
1 3
1
2
Output: Median = 2
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q06_Median_Of_Two_Sorted_Arrays.cpp -o A02_Q06_Median_Of_Two_Sorted_Arrays.exe && .\A02_Q06_Median_Of_Two_Sorted_Arrays.exe
