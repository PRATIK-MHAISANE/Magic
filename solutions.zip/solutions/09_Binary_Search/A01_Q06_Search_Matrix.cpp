// Problem: Search in a Row- and Column-Sorted Matrix
// Assignment: 1
// Question: 6
// Domain: 09_Binary_Search

/* Problem Statement:
Given an M x N matrix in which each row and each column is sorted in ascending order, write a method to find an element.

Approach:
Staircase Search starting at the top-right corner. Move left if current > target, move down if current < target.
*/

#include <bits/stdc++.h>
using namespace std;
pair<int,int> searchMatrix(vector<vector<int>>& mat, int target) {
    if (mat.empty() || mat[0].empty()) return {-1, -1};
    int row = 0;
    int col = mat[0].size() - 1;
    while (row < (int)mat.size() && col >= 0) {
        if (mat[row][col] == target) return {row, col};
        else if (mat[row][col] > target) col--;
        else row++;
    }
    return {-1, -1};
}

/* Sample Input & Output:
No sample I/O provided.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q06_Search_Matrix.cpp -o A01_Q06_Search_Matrix.exe && .\A01_Q06_Search_Matrix.exe
