// Problem: Queue Using Two Stacks Analysis
// Original file: A09_Q04.cpp

/* Problem Statement:
Queue Using Two Stacks Analysis

Approach:
Amortized analysis of queue implemented with two stacks.
*/

#include <bits/stdc++.h>
using namespace std;
 
int main() {
    int n;
    cin >> n;
    vector<int> inStack, outStack;
    long long bank = 0, totalActual = 0, totalAmortized = 0;
 
    cout << left << setw(5) << "No." << setw(16) << "Operation" << setw(8) << "Actual"
         << setw(11) << "Amortized" << setw(13) << "Credit bank" << "Result\n";
 
    for (int i = 1; i <= n; i++) {
        string op;
        cin >> op;
        long long actual = 0, charge = 0;
        string label, result;
 
        if (op == "enqueue") {
            int x;
            cin >> x;
            inStack.push_back(x);
            actual = 1;                    // one push
            charge = 2;                    // 1 for the push, 1 saved for this item's later move
            label = "enqueue(" + to_string(x) + ")";
            result = "-";
        } else {                           // dequeue
            label = "dequeue()";
            if (outStack.empty() && inStack.empty()) {
                result = "queue empty";
            } else {
                if (outStack.empty()) {
                    while (!inStack.empty()) {          // move everything, reversing the order
                        outStack.push_back(inStack.back());
                        inStack.pop_back();
                        actual++;                       // each move = 1 pop + 1 push, counted as 1 unit
                    }
                }
                result = to_string(outStack.back());
                outStack.pop_back();
                actual++;                               // the final pop
                charge = 1;
            }
        }
 
        bank += charge - actual;
        totalActual += actual;
        totalAmortized += charge;
        cout << left << setw(5) << i << setw(16) << label << setw(8) << actual << setw(11) << charge
             << setw(13) << bank << result << '\n';
        if (bank < 0) cout << "  !! credit went negative !!\n";
    }
 
    cout << "\nTotal actual cost    = " << totalActual << '\n';
    cout << "Total amortized cost = " << totalAmortized << '\n';
    cout << "Final credit bank    = " << bank << '\n';
    cout << "Total amortized cost <= 2n = " << 2 * n << "  ->  O(n)\n";
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra queue_using_stacks_v2.cpp -o queue_using_stacks_v2.exe && .\queue_using_stacks_v2.exe
