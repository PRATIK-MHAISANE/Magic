// Problem: Closest Pair of Points
// Assignment: 3
// Question: 4
// Domain: 19_Advanced_Algorithms

/* Problem Statement:
Find the two points that are closest to each other and report the minimum Euclidean distance.

Approach:
Divide and Conquer: Split by x, recurse. Merge halves and check 'strip' around dividing line in linear time.
*/

#include <bits/stdc++.h>
using namespace std;
struct Point { double x, y; };
double best = 1e18;
Point bestA, bestB;
double dist(const Point& a, const Point& b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}
void update(const Point& a, const Point& b) {
    double d = dist(a, b);
    if (d < best) { best = d; bestA = a; bestB = b; }
}
void closest(vector<Point>& P, vector<Point>& tmp, int lo, int hi) {
    int n = hi - lo;
    if (n <= 3) {
        for (int i = lo; i < hi; i++)
            for (int j = i + 1; j < hi; j++) update(P[i], P[j]);
        sort(P.begin() + lo, P.begin() + hi, [](const Point& a, const Point& b) { return a.y < b.y; });
        return;
    }
    int mid = lo + n / 2;
    double midX = P[mid].x;
    closest(P, tmp, lo, mid);
    closest(P, tmp, mid, hi);
    merge(P.begin() + lo, P.begin() + mid, P.begin() + mid, P.begin() + hi,
          tmp.begin() + lo, [](const Point& a, const Point& b) { return a.y < b.y; });
    copy(tmp.begin() + lo, tmp.begin() + hi, P.begin() + lo);
    vector<Point> strip;
    for (int i = lo; i < hi; i++)
        if (fabs(P[i].x - midX) < best) strip.push_back(P[i]);
    for (size_t i = 0; i < strip.size(); i++)
        for (size_t j = i + 1; j < strip.size() && strip[j].y - strip[i].y < best; j++)
            update(strip[i], strip[j]);
}
int main() {
    int n;
    cin >> n;
    vector<Point> P(n), tmp(n);
    for (int i = 0; i < n; i++) cin >> P[i].x >> P[i].y;
    sort(P.begin(), P.end(), [](const Point& a, const Point& b) {
        return a.x < b.x || (a.x == b.x && a.y < b.y);
    });
    closest(P, tmp, 0, n);
    cout << fixed << setprecision(4);
    cout << "Closest pair: (" << bestA.x << ", " << bestA.y << ") and (" << bestB.x << ", " << bestB.y << ")\n";
    cout << "Minimum distance = " << best << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 2
0 0
3 4
Output: Minimum distance = 5.0000
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A03_Q04_Closest_Pair_Points.cpp -o A03_Q04_Closest_Pair_Points.exe && .\A03_Q04_Closest_Pair_Points.exe
