// Problem: Stack Multipop Analysis
// Original file: A09_Q02.cpp

/* Problem Statement:
Stack Multipop Analysis

Approach:
Amortized analysis of stack with multipop operation.
*/

#include <bits/stdc++.h>
using namespace std;
 
int main() {
    int n;
    cin >> n;
    vector<string> st;                 // the stack of visited pages
 
    long long bank = 0, totalActual = 0, totalAmortized = 0;
 
    cout << left << setw(5) << "No." << setw(16) << "Operation" << setw(8) << "Actual"
         << setw(11) << "Amortized" << setw(14) << "Credit change" << setw(13) << "Credit bank"
         << "Stack size\n";
 
    for (int i = 1; i <= n; i++) {
        string op, arg;
        cin >> op;
        int actual = 0, charge = 0;
 
        if (op == "push") {
            cin >> arg;
            st.push_back(arg);
            actual = 1;
            charge = 2;                // 1 pays for the push, 1 is saved on the page
            arg = "push(" + arg + ")";
        } else if (op == "pop") {
            if (!st.empty()) { st.pop_back(); actual = 1; }
            charge = 0;                // paid by the credit saved at push time
            arg = "pop()";
        } else {                       // multipop k
            int k;
            cin >> k;
            int popped = 0;
            while (!st.empty() && popped < k) { st.pop_back(); popped++; }
            actual = popped;
            charge = 0;                // every popped page brings its own credit
            arg = "multipop(" + to_string(k) + ")";
        }
 
        bank += charge - actual;
        totalActual += actual;
        totalAmortized += charge;
 
        cout << left << setw(5) << i << setw(16) << arg << setw(8) << actual << setw(11) << charge
             << setw(14) << (charge - actual) << setw(13) << bank << st.size() << '\n';
        if (bank < 0) cout << "  !! credit went negative !!\n";
    }
 
    cout << "\nTotal actual cost    = " << totalActual << '\n';
    cout << "Total amortized cost = " << totalAmortized << '\n';
    cout << "Final credit bank    = " << bank << "  (never negative, so actual <= amortized)\n";
    cout << "Amortized cost <= 2n = " << 2 * n << "  ->  O(n)\n";
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra stack_multipop.cpp -o stack_multipop.exe && .\stack_multipop.exe
