// Problem: Dynamic Array Expansion Analysis
// Original file: A09_Q01.cpp

/* Problem Statement:
Dynamic Array Expansion Analysis

Approach:
Amortized analysis of dynamic array doubling.
*/

#include <bits/stdc++.h>
using namespace std;
 
int main() {
    int n;
    cin >> n;                          // number of insertions to perform
 
    int capacity = 1, size = 0;        // dynamic array starts with capacity 1
    long long totalCost = 0;
 
    cout << left << setw(12) << "Operation" << setw(8) << "Size" << setw(10) << "Capacity"
         << setw(13) << "Actual Cost" << setw(12) << "Total Cost" << "Amortized Cost\n";
 
    for (int i = 1; i <= n; i++) {
        int cost = 1;                          // writing the new element
        if (size == capacity) {                // array is full: double it
            cost += size;                      // copy every existing element
            capacity *= 2;
        }
        size++;
        totalCost += cost;
 
        cout << left << setw(12) << ("Insert " + to_string(i)) << setw(8) << size
             << setw(10) << capacity << setw(13) << cost << setw(12) << totalCost
             << fixed << setprecision(2) << (double)totalCost / i << '\n';
    }
 
    cout << "\nTotal cost of " << n << " insertions = " << totalCost << '\n';
    cout << "Amortized cost per insertion = " << fixed << setprecision(3)
         << (double)totalCost / n << "  (bound: at most 3)\n";
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra dynamic_array_expansion.cpp -o dynamic_array_expansion.exe && .\dynamic_array_expansion.exe
